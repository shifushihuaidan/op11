<?php
$a=(int)$_GET['a'];
$b=(int)$_GET['b'];
$c=$a+$b;
echo $c;
?>