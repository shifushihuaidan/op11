<?php
$name1=$_GET['name1'];
$mima=$_GET['mima'];
if($name1=="������"&&$mima=="123")
	echo "1";
else
    echo "0";
?>