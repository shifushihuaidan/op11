<?php
$name1=$_POST['name1'];
$mima=$_POST['mima'];
if($name1=="123")//&&$mima=="07944")
	echo "1";
else
    echo "0";
?>