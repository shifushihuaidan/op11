<?php
$a=(int)$_POST['a'];
$b=(int)$_POST['b'];
$c=$a+$b;
echo $c;
?>