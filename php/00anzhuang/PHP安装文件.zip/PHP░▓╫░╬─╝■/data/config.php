<?php

$mysql_host		= "localhost";
$mysql_user		= "root";
$mysql_pass		= "";
$mysql_dbname	= "new_php100";
$mysql_tag		= "new_";

?>