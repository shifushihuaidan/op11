package com.douban.android.util;


public class DoubanUtil {
	public static String apiKey = "05bcd1326532164a113673972f9642de";
	public static String secret = "8194622cd9e873a8";
	public static String callback = "haiyang://callback";

	

}
