package com.douban.android.util;

/**
 * @author Administrator
 *  处理和sharePreference相关
 */
public class PreferencesUtil {
	public final static  String preferencesDouban ="douban";
	public final static String  oauthToken ="oauth_token";
	public final static String  oauthTokenSecret="oauth_token_secret";
	public final static String  acessToken ="acess_token";
	public final static String  acessTokenSecret ="acess_token_secret";
	public final static String  userName ="user_name";
	


	
}
