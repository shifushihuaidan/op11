// zhuce.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "cc.h"
#include "zhuce.h"
#include "afxdialogex.h"


// zhuce �Ի���

IMPLEMENT_DYNAMIC(zhuce, CDialog)

zhuce::zhuce(CWnd* pParent /*=NULL*/)
	: CDialog(zhuce::IDD, pParent)
{

}

zhuce::~zhuce()
{
}

void zhuce::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(zhuce, CDialog)
END_MESSAGE_MAP()


// zhuce ��Ϣ��������
