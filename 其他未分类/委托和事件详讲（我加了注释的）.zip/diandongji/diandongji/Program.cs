﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace diandongji
{

    /*
     作者：海贼王
     * 第一部分
     本例子我写的是：一个电动机，转动会发热，当他温度过高时，报警器抱紧，发出声音说
     * “电动机温度过高，当前温度为XXXX”，而显示器显示“电动机温度过高，当前温度为XXXX”
     * 要看第二部分的，请把注释删掉，然后把第一把粉加上注释,代码我折叠了的
     */
    #region 
    
    //电动机类
    public class diandongji
    {
        private int wendu=0;//定义一个温度，按理说不应该是0度，
        public delegate void de1(int w);//声明一个委托，
        public event de1 ev1;//生命一个事件，对委托de1进行封装,也就是说一旦有了事件来凤庄
     //委托de1,呢么委托de1就变成了私有的，不信的话，你可以写:diandongji d1=new diandongji();
     // d1.de1 d1=new de1(baojin); 这个报错
        public void jiare()//加热函数，就是让电动机温度升高
        {
            for (int i=0;i<100;i++)
                {
                    wendu++;
                    if (wendu > 96)//温度杜宇96都市，调用注册了的函数
                    {
                        ev1(wendu);//这里会调用所有注册及绑定了的函数
                    }
                }
        }
    }
    //金宝器类
    public class baojinqi//报警器类，用来抱紧
    {
        public void baojin(int w)//抱紧函数
        {
            Console.WriteLine("报警器：电动机温度过高，当前温度为{0}",w);//打印，当前温度
            Console.WriteLine();
        }
    }
    //显示器类
    public class xianshiqi//显示器类，用来显示
    {
        public void xianshi(int w)
        {
            Console.WriteLine("显示器：电动机温度过高，当前温度为{0}", w);//打印，当亲温度
            Console.WriteLine();
        }
    }
    class Program//这个不用解释了吧，每个C#项目都有的一个类
    {
        static void Main(string[] args)//入口函数，所有程序都从这里开始
        {
            diandongji d1 = new diandongji();//定义一个电动积累对象
            baojinqi bao=new baojinqi();//定义一个包金磊对象
            xianshiqi xian=new xianshiqi();//定义一个显示器类对象
            d1.ev1 += bao.baojin;//绑定函数，也叫注册函数，bao.baojin是抱紧累的函数，
                          //记住这里写函数名字，不要加括号，说到这里我又不得不
                           //  讽刺几句C#，其实这里就是把函数地址赋值给ev1
            d1.ev1 += xian.xianshi;//和上面那句一样
            d1.jiare();//加热
        }
    }
     
    #endregion


    /*
     * 第二部分，如果你把第一部分看懂了，还想更深入勒戒委托和时间的的话，请看下面的着敌人部分，
     * 本例子我写的是：一个电动机，转动会发热，当他温度过高时，报警器抱紧，发出声音说
     * “电动机温度过高，当前温度为XXXX”，而显示器显示“电动机温度过高，当前温度为XXXX”,
     * 而现在，我想让包近期布置是报出它的温度，还能说出他的版本号，生产厂家等信息，而显示器
     * 也布置显示温度，也显示版本号，生产厂家等信息，
     * 所以这个例子和C#中的什么点击事件，很像，他们也是这样写的，只是还有些许不同，例如他会把
     * 注册的那个农委virtual等等
     * */
    #region
    //电动机类
    /*
    
    public class diandongji//这里还是电动机类
    {
        private int wendu = 0;//温度
        public delegate void de1(object sender,cc e);//声明委托，这里是不是很熟悉，没错，就是和
                                                  //你们C#窗体设计，双击一个东西出来的那个事件
                                                //处理函数的参数很想对吧,这个本来有很多要说的
                                                 //但时间有限，不说了
        public event de1 ev1;//声明事件
        public string changji = "海贼王加工厂";//厂家，这些写的不规范，只是为了本例子而已
        public int shouming = 10;//使用寿命
        public class cc :EventArgs   //我重新加一个类，来获取温度，
                                     //为什么要继承这个类eventargs，这只是为了和C#的一样
        {
            public int wendu;//温度，因为电动机累的温度是私有的
            public cc(int wendu)//够着函数
            {
                this.wendu = wendu;//获取电动机类的温度
            }
        }
        protected void onev1(cc e)//通过调用事件，来调用注册的函数
        {
            if (ev1!=null)//有函数注册
            {
                ev1(this,e);//调用所有注册的函数
            }
        }
        public void jiare()//加热
        {
            for (int i = 0; i < 100; i++)
            {
                wendu++;
                if (wendu > 96)
                {
                    cc c1 = new cc(wendu);//new 一个cc类
                    onev1(c1);//调用上面那个函数，通过调用事件，来调用注册的函数
                }
            }
        }
    }
    //金宝器类
    public class baojinqi//下面这些解释还是那个面我注释了的
    {
        public void baojin(object sender,diandongji.cc e)
        {
            diandongji d2=(diandongji) sender;//拆箱
            Console.WriteLine("报警器：电动机温度过高，当前温度为{0}", e.wendu);
            Console.WriteLine("生厂厂家{0},寿命{1}",d2.changji,d2.shouming);
            Console.WriteLine();
        }
    }
    //显示器类
    public class xianshiqi
    {
        public void xianshi(object sender, diandongji.cc e)
        {
            diandongji d2 = (diandongji)sender;
            Console.WriteLine("显示器：电动机温度过高，当前温度为{0}", e.wendu);
            Console.WriteLine("生厂厂家{0},寿命{1}", d2.changji, d2.shouming);
            Console.WriteLine();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            diandongji d1 = new diandongji();
            baojinqi bao = new baojinqi();
            xianshiqi xian = new xianshiqi();
            d1.ev1 += bao.baojin;
            d1.ev1 += xian.xianshi;
            d1.jiare();
        }
    }
    */
    #endregion

}
