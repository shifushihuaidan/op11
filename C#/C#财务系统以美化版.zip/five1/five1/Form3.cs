﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace five1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 f1 = new Form4();
            f1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 f1 = new Form6();
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 f1 = new Form8();
            f1.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form9 f1 = new Form9();
            f1.ShowDialog();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            if (Form1.shenfen == "管理员")
            {
                button3.Enabled = button1.Enabled =
                    button1.Enabled = button4.Enabled =
                    true;
                //label2.Text ="当前身份："+ Form1.shenfen;
            }
            else
            {
                button3.Enabled = false;
            }
            label2.Text = "当前身份：" + Form1.shenfen;
        }
    }
}
