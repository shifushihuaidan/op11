﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace five1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            //Form1.con.Open();
            string sql = "select * from user1";
            SqlCommand com = new SqlCommand(sql, Form1.con);
            Form1.cb = new SqlCommandBuilder(Form1.da);
            Form1.da.SelectCommand = com;
            Form1.dt1.Clear();
            Form1.ds.Clear();
            Form1.da.Fill(Form1.dt1);
            dataGridView1.DataSource = Form1.dt1;
            //Form1.con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 添加用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("您确定要更新吗？",
              "会更新数据库信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            if (result == DialogResult.OK)
            {
                //执行OK的代码
                Form1.da.Update(Form1.dt1);
                Form4_Load(this,e);
            }
            else
            {
                //执行Cancel的代码
            }
        }

        private void 修改用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 f1 = new Form5();
            f1.ShowDialog();
        }

        private void 删除该用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            //MessageBox.Show(i.ToString());
            if (i == 0)
            {
                MessageBox.Show("最高级别管理员,不能删除");
            }
            else
            {
                DialogResult result = MessageBox.Show("您确定要删除吗？",
                  "暂时不会更新数据库信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
                if (result == DialogResult.OK)
                {
                    //执行OK的代码
                    //int i = dataGridView1.CurrentRow.Index;
                    DataRow dr = Form1.dt1.Rows[i];
                    dr.Delete();
                }
                else
                {
                    //执行Cancel的代码
                }
            }
            dataGridView1.DataSource = Form1.dt1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sql = "select * from user1 where name='"
                + textBox1.Text + "'" ;
            SqlCommand com = new SqlCommand(sql, Form1.con);
            Form1.cb = new SqlCommandBuilder(Form1.da);
            Form1.da.SelectCommand = com;
            Form1.dt1.Clear();
            Form1.ds.Clear();
            Form1.da.Fill(Form1.dt1);
            dataGridView1.DataSource = Form1.dt1;
        }
    }
}
