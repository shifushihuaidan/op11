﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace three
{
    public partial class Form1 : Form
    {
        private int[] ims;
        private int a1;//点击第一个图片
        private int a2;
        private int b11;//点击的第一张图片的值
        private int b2;
        private int count = 0;//计数，点击的次数
        private int t1=0;//3秒翻转
        //private int[] bb;//存放索引
        //private int[] b1;
        private int t2=0;
        private int c1=1;
        private int t3 = 0;//已用时间
        private int red;//最高纪录
        private int duishu=0;//匹配对数
        public Form1()
        {
            InitializeComponent();
            ims = new int[16];
            //bb = new int[16];
           // b1 = new int[16];
            fun9();
        }

        private void 游戏归责ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //base.Close();
            //this.Close();
            Application.Exit();
        }
        private void fun10()
        {
            timer1.Enabled = timer2.Enabled = timer3.Enabled = false;
            t1 = t2 = t3=0;
        }
        private void 新游戏ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fun10();
            int i1 = 0;
            for (int i = 0; i < ims.Length; i++)
            { 
                ims[i]=-1;
            }
            for (int j = 1; j <= 8; j++)
            {
                fun(j);
                fun(j);
            }
            foreach (Control c1 in base.Controls)
            {
                if (c1 is PictureBox)
                {
                    
                    /*bb[i1] = Convert.ToInt32(((PictureBox)c1).Tag);
                    b1[i1]=ims[bb[i1]];
                    ((PictureBox)c1).Visible = true;
                    ((PictureBox)c1).Image=imageList1.Images[b1[i1]];*/
                    int bb = Convert.ToInt32(((PictureBox)c1).Tag);
                    int b1 = ims[bb];
                    ((PictureBox)c1).Visible = true;
                    ((PictureBox)c1).Enabled = false;
                    ((PictureBox)c1).Image = imageList1.Images[b1];
                    i1++;
                }
            }
            timer1.Enabled = true;
           // MessageBox.Show("当前t1为{0}",t1.ToString());
           /* if (t1 == 3)
            {
                fun1();
                timer1.Enabled =false;
                t1 = 0;
            }*/
           /* i1 = 0;
            foreach (Control c1 in base.Controls)
            {
                if (c1 is PictureBox)
                {
                    ((PictureBox)c1).Visible = false;
                    ((PictureBox)c1).Image = imageList1.Images[b1[i1]];
                    i1++;
                }
            }*/
            timer3.Enabled = true;
        }
        private void fun1()//翻转图片
        {
            foreach (Control c1 in base.Controls)
            {
                if (c1 is PictureBox)
                {
                    ((PictureBox)c1).Image = imageList1.Images[0];
                }
            }
        }
        private void fun(int i)
        {
            Random r1 = new Random();
            int aa = r1.Next(16);
            if (ims[aa] != -1)
            {
                while (ims[aa] != -1)
                {
                    aa = r1.Next(16);
                }
            }
            ims[aa] = i;
        }
        private void fun3(int a)//将制定的框设为不见
        {
            foreach (Control item in this.Controls)
            {
                if (item is PictureBox)
                {
                    if (Convert.ToInt32(((PictureBox)item).Tag) == a)
                    {
                        ((PictureBox)item).Visible = false;
                    }
                }
            }

        }
        private void fun4(int aa,int bb)//设置其他图片不可点击,除开两指定图片
        {
            foreach (Control item in this.Controls)
            {
                if (item is PictureBox)
                {
                    for (int i = 0; i < 16; i++)
                    {
                        if ((Convert.ToInt32(((PictureBox)item).Tag) != aa)&&
                            (Convert.ToInt32(((PictureBox)item).Tag) != bb))
                        {
                            ((PictureBox)item).Enabled = false;
                        }
                    }
                }
            }
        }
        private void fun5()//设置其他图片可点击
        {
            foreach (Control item in this.Controls)
            {
                if (item is PictureBox)
                {
                    ((PictureBox)item).Enabled = true;        
                }
            }
        }
        private void fun9()//设置其他图片不可点击
        {
            foreach (Control item in this.Controls)
            {
                if (item is PictureBox)
                {
                    ((PictureBox)item).Enabled = false;
                }
            }
        }
        private void fun6()//判断是否赢了，赢了就弹出对话
        {
            if (duishu == 8)
            {
                duishu = 0;
                timer3.Enabled = false;
                if (red > t3)
                {
                    red = t3;
                    fun7(t3.ToString());
                    //timer3.Enabled = false;
                    t3 = 0;
                    MessageBox.Show("你破记录了，真厉害");
                    label1.Text = "最高纪录:" + red + "秒";
                }
                else
                {
                    MessageBox.Show("配对完成，用时" + t3.ToString());
                }
            }
        }
        public static void fun7(string st)//将记录写入文件
        {
            FileStream fs = new FileStream("\\re.txt", FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            //开始写入
            sw.Write(st);
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();
        }
        public static string fun8()//独处最高纪录
        {
            StreamReader sr = new StreamReader("\\re.txt", Encoding.Default);
            String line;
            string s1 = "";
            while ((line = sr.ReadLine()) != null)
            {
                s1 = s1 + line;
            }
            return s1;
        }
        private void pictureBox1_Click(object sender, EventArgs e)//图片点击事件
        {
            count += 1;
            if (count == 1)//第一次点击
            {
                 a1 = Convert.ToInt32(((PictureBox)sender).Tag);
                 b11 =ims[a1];
                 ((PictureBox)sender).Image = imageList1.Images[b11];
            }
            if(count==2)
            {
                a2 = Convert.ToInt32(((PictureBox)sender).Tag);
                b2 = ims[a2];
                fun4(a1, a2);
                ((PictureBox)sender).Image = imageList1.Images[b2];
                if (a1!=a2&&b11 == b2)
                {
                    MessageBox.Show("配对成功");
                    duishu++;
                    fun3(a1);
                    fun3(a2);
                    fun5();
                }
                else
                {
                    c1 = 0;
                    timer2.Enabled = true;
                    //fun1();//翻转
                }
                count = 0;
            }
            fun6();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            t1++;
            if (t1 == 3)
            {
                fun1();
                timer1.Enabled = false;
                t1 = 0;
                foreach (Control c1 in base.Controls)
                {
                    if (c1 is PictureBox)
                    {
                        ((PictureBox)c1).Enabled = true;
                    }
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (c1 == 0)
            {
                t2++;
                if (t2 == 1)
                {
                    fun1();
                    timer2.Enabled = false;
                    fun5();
                    t2 = 0;
                }
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            t3++;
            string cc="已用时：";
            label2.Text = cc + t3.ToString() + "秒";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*string ss = "100";
            fun7(ss);*/
            string s2 = fun8();
            label1.Text ="最高纪录:"+ s2+"秒";
            red = int.Parse(s2);
        }
    }
}
