﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace seven1
{
    class InThread//线程类
    {
        private Control A;
        private int Seed;
        public void RunInThread()//取随机数并延迟
        {
            Random random = new Random(this.Seed);
            while (true)
            {
                this.A.Text = random.Next(0, 10).ToString();
                Thread.Sleep(100);
            }
        }
        public void SetNumber(Control B, int SeedHere)
        {//设置数字
            this.A = B;
            this.Seed = SeedHere;
        }
    }
}
