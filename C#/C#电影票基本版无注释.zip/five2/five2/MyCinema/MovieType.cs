using System;
namespace MyCinema
{
	public enum MovieType
	{
		Comedy,
		War,
		Romance,
		Action,
		Cartoon,
		Thriller
	}
}
