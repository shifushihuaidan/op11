using System;
using System.IO;
namespace MyCinema
{
	[Serializable]
	public class Ticket : IPrintable
	{
		private Seat seat;
		private int price;
		private ScheduleItem scheduleItem;
		public Seat Seat
		{
			get
			{
				return this.seat;
			}
			set
			{
				this.seat = value;
			}
		}
		public int Price
		{
			get
			{
				return this.price;
			}
			set
			{
				this.price = value;
			}
		}
		public ScheduleItem ScheduleItem
		{
			get
			{
				return this.scheduleItem;
			}
			set
			{
				this.scheduleItem = value;
			}
		}
		public Ticket()
		{
		}
		public Ticket(ScheduleItem scheduleItem, Seat seat)
		{
			this.ScheduleItem = scheduleItem;
			this.Seat = seat;
		}
		public virtual void CalcPrice()
		{
			this.Price = this.ScheduleItem.Movie.Price;
		}
		public virtual void Print()
		{
			string path = this.ScheduleItem.Time + " " + this.Seat.SeatNum + ".txt";
			FileStream fileStream = new FileStream(path, FileMode.Create);
			StreamWriter streamWriter = new StreamWriter(fileStream);
			streamWriter.WriteLine("***************************");
			streamWriter.WriteLine("        青鸟影院");
			streamWriter.WriteLine("---------------------------");
			streamWriter.WriteLine(" 电影名：\t{0}", this.ScheduleItem.Movie.MovieName);
			streamWriter.WriteLine(" 时间：\t{0}", this.ScheduleItem.Time);
			streamWriter.WriteLine(" 座位号：\t{0}", this.Seat.SeatNum);
			streamWriter.WriteLine(" 价格：\t{0}", this.Price.ToString());
			streamWriter.WriteLine("***************************");
			streamWriter.Close();
			fileStream.Close();
		}
	}
}
