using System;
namespace MyCinema
{
	[Serializable]
	public class ScheduleItem
	{
		private string time;
		private Movie movie;
		public string Time
		{
			get
			{
				return this.time;
			}
			set
			{
				this.time = value;
			}
		}
		public Movie Movie
		{
			get
			{
				return this.movie;
			}
			set
			{
				this.movie = value;
			}
		}
		public ScheduleItem()
		{
			this.movie = new Movie();
		}
	}
}
