using System;
namespace MyCinema
{
	public class TicketFactory
	{
		public static Ticket CreateTicket(ScheduleItem scheduleItem, Seat seat, int discount, string customerName, string type)
		{
			Ticket result = null;
			if (type != null)
			{
				if (!(type == "student"))
				{
					if (!(type == "free"))
					{
						if (type == "")
						{
							result = new Ticket(scheduleItem, seat);
						}
					}
					else
					{
						result = new FreeTicket(scheduleItem, seat, customerName);
					}
				}
				else
				{
					result = new StudentTicket(scheduleItem, seat, discount);
				}
			}
			return result;
		}
	}
}
