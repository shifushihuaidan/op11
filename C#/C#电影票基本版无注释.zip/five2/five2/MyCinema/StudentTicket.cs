using System;
using System.IO;
namespace MyCinema
{
	[Serializable]
	public class StudentTicket : Ticket, IPrintable
	{
		private int discount;
		public int Discount
		{
			get
			{
				return this.discount;
			}
			set
			{
				this.discount = value;
			}
		}
		public StudentTicket()
		{
		}
		public StudentTicket(ScheduleItem scheduleItem, Seat seat, int discount) : base(scheduleItem, seat)
		{
			this.Discount = discount;
		}
		public override void CalcPrice()
		{
			base.Price = base.ScheduleItem.Movie.Price * this.Discount / 10;
		}
		public override void Print()
		{
			string path = base.ScheduleItem.Time + " " + base.Seat.SeatNum + ".txt";
			FileStream fileStream = new FileStream(path, FileMode.Create);
			StreamWriter streamWriter = new StreamWriter(fileStream);
			streamWriter.WriteLine("***************************");
			streamWriter.WriteLine("     青鸟影院 (学生)");
			streamWriter.WriteLine("---------------------------");
			streamWriter.WriteLine(" 电影名：\t{0}", base.ScheduleItem.Movie.MovieName);
			streamWriter.WriteLine(" 时间：\t{0}", base.ScheduleItem.Time);
			streamWriter.WriteLine(" 座位号：\t{0}", base.Seat.SeatNum);
			streamWriter.WriteLine(" 价格：\t{0}", base.Price.ToString());
			streamWriter.WriteLine("***************************");
			streamWriter.Close();
			fileStream.Close();
		}
	}
}
