﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace five1
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            string sql = "select sum(amount) from shouzhi where inorout='收入'";
            SqlCommand com = new SqlCommand(sql,Form1.con);
            int n1 = (int)com.ExecuteScalar();
            sql = "select sum(amount) from shouzhi where inorout='支出'";
            com.CommandText = sql;
            int n2 = (int)com.ExecuteScalar();
            sql = "select SUM(jinge) from jiedai where jieordai='借出'";
            com.CommandText = sql;
            int n3 = (int)com.ExecuteScalar();
            sql = "select SUM(jinge) from jiedai where jieordai='贷入'";
            com.CommandText = sql;
            int n4 = (int)com.ExecuteScalar();
            label2.Text = n1.ToString();
            label4.Text = n2.ToString();
            label6.Text = (Math.Round((decimal)n1/n2,9)).ToString();
            label11.Text = n3.ToString();
            label9.Text = n4.ToString();
            label7.Text = (Math.Round((decimal)n3/n4,9)).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
