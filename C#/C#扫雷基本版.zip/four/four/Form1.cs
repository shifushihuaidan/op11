﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace four
{
    public partial class Form1 : Form
    {
        private Button[,] dilei;   //定义一个二维数组 用于显示雷区
        private int xnum = 9;   //初始化累的列数（初级时的行列数）
        private int ynum = 9;   //初始化雷的行数
        public static int zdyxnum;   //用于自定义中的列数
        public static int zdyynum;   //用于自定义中的行数
        private int leinum = 10;   //初始化第雷的总数
        public static int zdyleinum;   //用于记录自定义中的雷数
        private int[,] turn;//-1 表示这个位置已经翻开；
        //0 表示这个位置没有翻开；1 表示这个位置插上红旗；
        public static int time1 = 0;   //计量所用的时间
        private int time2 = 0;   //初始化时间
        private int restlei = 10;   //用于改变等级时载入剩余雷数
        private int leidaxiao = 20;   // 控制雷块的大小
        public Form1()
        {
            InitializeComponent();
        }

        private void 新游戏ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Image = Image.FromFile("face.bmp");
            delall();
            restlei = leinum;
            time1 = 0;
            label2.Text = time1.ToString();
            buleiqu();
            youxiinit();
            timer1.Enabled = true;
        }
        private void delall()   //删除所有的雷区
        {
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum; j++)   //二维数组逐个删除
                {
                    Button n = new Button();   //定义一个新的button
                    n = (Button)dilei[i, j];   //强制类型转换
                    this.Controls.Remove(dilei[i, j]);   //删除所指雷区
                }
        }
        private void buleiqu()
        {
            turn=new int[xnum,ynum];
            dilei = new Button[xnum, ynum];
            for(int i=0;i<xnum;i++)
                for (int j = 0; j < ynum; j++)
                {
                    dilei[i, j] = new Button();
                    this.Controls.Add(dilei[i, j]);
                    dilei[i, j].Left = 10 + leidaxiao * i;
                    dilei[i, j].Top = 65 + leidaxiao * j;
                    dilei[i, j].Width = leidaxiao;
                    dilei[i, j].Height = leidaxiao;
                    dilei[i, j].Font = new Font("宋体", 10.5F, 
                        FontStyle.Bold, GraphicsUnit.Point, ((byte)(134)));
                    dilei[i, j].BackgroundImageLayout = 
                        System.Windows.Forms.ImageLayout.Stretch;
                    dilei[i, j].Name = "lei" + (i + j*xnum).ToString();
                    dilei[i, j].MouseUp += new MouseEventHandler(fun1);   
                    dilei[i, j].Visible = true;   //控制Mines按钮的可见
                }
            bianform();
        }
        private void youxiinit()  //游戏初始化
        {
            restlei = leinum;
            label1.Text = restlei.ToString();
            for (int x = 0; x < xnum; x++)
                for (int y = 0; y < ynum; y++)
                {
                    dilei[x, y].Text = "";
                    dilei[x, y].Visible = true;
                    dilei[x, y].Enabled = true;
                    dilei[x, y].Tag = null;
                    dilei[x, y].BackgroundImage = null;
                    turn[x, y] = 0;        //刚开始都未插旗、未表示为雷
                }
            bulei();
        }
        private void bulei() //布雷
        {
            int x, y;
            Random s = new Random();
            //取随机数
            for (int i = 0; i < leinum; )
            {
                //取随机数
                x = s.Next(xnum); //取随机数，
                //返回一个小于所指定最大值的非负随机数
                y = s.Next(ynum);
                if (Convert.ToInt16(dilei[x, y].Tag) != 1)
                {
                    //==1时，表示地雷
                    dilei[x, y].Tag = 1;//修改属性
                    i++;
                }
            }
            label1.Text = leinum.ToString();
            time1 = 0;
            label2.Text = time2.ToString();
        }
        private void fun1(object sender, MouseEventArgs e)
        {
            String btName;
            Button bClick = (Button)sender;
            btName = bClick.Name;
            int n = Convert.ToInt16(btName.Substring(3));
            int x = n % xnum;
            int y = n / xnum;
            switch (e.Button)
            {
                case MouseButtons.Left:
                    if (Convert.ToInt16(dilei[x, y].Tag) != 1)
                    {
                        detpicture(GetAroundNum(x, y), x, y);
                        dilei[x, y].Enabled = false;
                        zhankailei(x, y);
                        if (Victory())
                        {
                            fun2();
                            MessageBox.Show("恭喜您，尼赢了!", "游戏结束");
                            timer1.Enabled = false;//停止计时
                        }
                    }
                    else
                    {
                        dilei[x, y].BackgroundImage = Image.FromFile("mine1.bmp");
                        button1.Image = Image.FromFile("face1.jpg");
                        MessageBox.Show("你才到地雷了!", "游戏结束");
                        timer1.Enabled = false;//停止计时
                    }
                    break;
                case MouseButtons.Right:
                    dilei[x, y].BackgroundImage = Image.FromFile("flag.bmp");
                    if (turn[x, y] == 1)//表示这个位置插上红旗
                    {
                        turn[x, y] = 0;//取消红旗,表示这个位置没有翻开
                        restlei++;
                        dilei[x, y].BackgroundImage = null;
                    }
                    else
                    {
                        turn[x, y] = 1;//表示这个位置插上红旗
                        restlei--;
                    }
                    label1.Text = restlei.ToString();
                    bool s=Victory();
                    //MessageBox.Show("Victory返回值是"+s.ToString(), "游戏结束");
                    if (Victory())
                    {
                        MessageBox.Show("恭喜您，尼赢了!", "游戏结束");
                        timer1.Enabled = false;//停止计时
                    }
                    break;
            }
        }
        private bool Victory()// 检测是否胜利
        {
            int c1=0;
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum;j++)
                {
                    if (Convert.ToInt16(dilei[i, j].Tag) == 1
                        && turn[i, j] == 1)
                        c1++;
                    //没翻开且未标示,则未成功
                    /*if (dilei[i, j].Enabled == true && turn[i, j] != 1)
                        return false;
                    //不是雷却误标示为雷,则也未成功
                    if (Convert.ToInt16(dilei[i, j].Tag) != 1
                        && turn[i,j] == 1)
                        return false;*/
                }
            if (c1 == leinum)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void fun2()//将地图中所有雷标识出来
        {
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum; j++)
                    if (Convert.ToInt16(dilei[i, j].Tag) == 1)
                    {
                        //==1时，代表这个位置是地雷
                        dilei[i, j].BackgroundImage = Image.FromFile("mine.bmp");
                    }
        }
        private void detpicture(int n, int i, int j)//用于调用不同的图片显示所单击按钮周围所剩的雷数
        {
            switch (n)
            {
                case 1:
                    {
                        dilei[i, j].BackgroundImage = Image.FromFile("1.PNG");
                        break;
                    }
                case 2:
                    {
                        dilei[i, j].BackgroundImage = Image.FromFile("2.PNG");
                        break;
                    }
                case 3:
                    {
                        dilei[i, j].BackgroundImage = Image.FromFile("3.PNG");
                        break;
                    }
                case 4:
                    {
                        dilei[i, j].BackgroundImage = Image.FromFile("4.PNG");
                        break;
                    }
                case 5:
                    {
                        dilei[i, j].BackgroundImage = Image.FromFile("5.PNG");
                        break;
                    }
                case 6:
                    {
                        dilei[i, j].BackgroundImage = Image.FromFile("6.PNG");
                        break;
                    }
                case 7:
                    {
                        dilei[i, j].BackgroundImage = Image.FromFile("7.PNG");
                        break;
                    }
                case 8:
                    {
                        dilei[i, j].BackgroundImage = Image.FromFile("8.PNG");
                        break;
                    }
            }
        }
        private int GetAroundNum(int row, int col)//用于获取所单击按钮周围8个雷块中所剩的雷数
        {
            int i, j;
            int aa = 0;//定义所生的雷数，开始为0
            int row1 = (row == 0) ? 0 : row - 1;
            int row2 = row + 2;
            int col1 = (col == 0) ? 0 : col - 1;
            int col2 = col + 2;
            for (i = row1; i < row2; i++)
            {
                for (j = col1; j < col2; j++) //[row,col]处没有雷
                {
                    if (!isinleiqu(i, j))   //判断是否在扫雷区域
                        continue;
                    if (Convert.ToInt16(dilei[i, j].Tag) == 1) aa++;
                }
            }
            return aa;   //返回所生的雷数
        }
        private bool isinleiqu(int row, int col)   //判断是否已出雷区
        {
            return (row >= 0 && row < xnum 
                && col >= 0 && col < ynum);   //返回true or false
        }
        private void zhankailei(int row, int col)
        {
            int i, j;
            int row1 = (row == 0) ? 0 : row - 1;
            int row2 = row + 2;
            int col1 = (col == 0) ? 0 : col - 1;
            int col2 = col + 2;
            int around =GetAroundNum(row, col);//对周围一个雷都没有的空白区域拓展
            if (around == 0)
            {
                dilei[row, col].Enabled = false;
                for (i = row1; i < row2; i++)
                {
                    for (j = col1; j < col2; j++)
                    {
                        //对于周围可以拓展的区域进行的规拓展			
                        if (!isinleiqu(i, j)) continue;
                        if (!(i == row && j == col) 
                            && dilei[i, j].Enabled != false)
                        {
                            zhankailei(i, j);
                        }
                        dilei[i, j].Enabled = false; //周围无雷的区域按钮无效
                        detpicture(GetAroundNum(i, j), i, j);
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            初级ToolStripMenuItem.Checked = true;   //使菜单中的初级可用
            loadlei();   //用于解决开始时单击任意按钮均胜利的问题
            youxiinit();    //游戏初始化
            timer1.Enabled = true;   //开启时钟计时
        }
        private void loadlei() //解决在开始时单击人一个按钮均会胜利的问题，
            //一下不做解释。
        {
            turn = new int[xnum, ynum];
            dilei = new Button[xnum, ynum];
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum; j++)
                {
                    dilei[i, j] = new Button();
                    this.Controls.Add(dilei[i, j]);
                    dilei[i, j].Left = 10 + leidaxiao * i;
                    dilei[i, j].Top = 65 + leidaxiao * j;
                    dilei[i, j].Width = leidaxiao;
                    dilei[i, j].Height = leidaxiao;
                    dilei[i, j].Font = new Font("宋体", 10.5F,
                        FontStyle.Bold, GraphicsUnit.Point, ((byte)(134)));
                    dilei[i, j].BackgroundImageLayout =
                        System.Windows.Forms.ImageLayout.Stretch;
                    dilei[i, j].Name = "lei" + (i + j * xnum).ToString();
                    dilei[i, j].MouseUp += new MouseEventHandler(fun1);
                    dilei[i, j].Visible = true;   //控制Mines按钮的可见
                }
        }

        private void 初级ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Image = Image.FromFile("face.bmp");   //开始时，让button1按钮的Image设为face.bmp
            初级ToolStripMenuItem.Checked = true;   //初级按钮可用
            中级ToolStripMenuItem.Checked = false;   //中级按钮不可用
            高级ToolStripMenuItem.Checked = false;   //高级按钮不可用
            自定义ToolStripMenuItem.Checked = false;   //自定义按钮不可用
            delall();   //删除残余雷片
            xnum = 9;   //定义雷区的列数
            ynum = 9;   //定义雷区的行数
            leinum = 10;   //定义总雷数
            restlei = leinum;   //计数剩余的雷数
            label1.Text = time1.ToString();   //用于在开始界面显示所用的时间
            buleiqu(); //开始游戏
            youxiinit();//游戏初始化
            timer1.Enabled = true;   //触发计时器
            bianform();
        }

        private void 中级ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Image = Image.FromFile("face.bmp");   //开始时，让button1按钮的Image设为face.bmp
            初级ToolStripMenuItem.Checked = false;   //初级按钮可用
            中级ToolStripMenuItem.Checked = true;   //中级按钮不可用
            高级ToolStripMenuItem.Checked = false;   //高级按钮不可用
            自定义ToolStripMenuItem.Checked = false;   //自定义按钮不可用
            delall();   //删除残余雷片
            xnum = 16;   //定义雷区的列数
            ynum = 16;   //定义雷区的行数
            leinum = 40;   //定义总雷数
            restlei = leinum;   //计数剩余的雷数
            label1.Text = time1.ToString();   //用于在开始界面显示所用的时间
            buleiqu(); //开始游戏
            youxiinit();//游戏初始化
            timer1.Enabled = true;   //触发计时器
            bianform();
        }

        private void 高级ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Image = Image.FromFile("face.bmp");   //开始时，让button1按钮的Image设为face.bmp
            初级ToolStripMenuItem.Checked = false;   //初级按钮可用
            中级ToolStripMenuItem.Checked = false;   //中级按钮不可用
            高级ToolStripMenuItem.Checked = true;   //高级按钮不可用
            自定义ToolStripMenuItem.Checked = false;   //自定义按钮不可用
            delall(); //删除残余雷片
            xnum = 30; //定义雷区的列数
            ynum = 16;   //定义雷区的行数
            leinum = 99;   //定义总雷数
            restlei = leinum;   //计数剩余的雷数
            label1.Text = time1.ToString();   //用于在开始界面显示所用的时间
            buleiqu(); //开始游戏
            youxiinit();//游戏初始化
            timer1.Enabled = true;   //触发计时器
            bianform();
        }
        private void bianform()//决定form1的整体框架
        {
            button1.Location = new Point(-10 + xnum * leidaxiao / 2, -1); //控制form1中的button1按钮开始的位置
            button2.Location = new Point(-25 + xnum * leidaxiao / 2, 65 
                + ynum * leidaxiao);////控制form1中的button2按钮开始的位置
            panel1.Size = new Size(30 + leidaxiao * xnum, 35);   //控制panel1的大小
            label2.Location = new Point(xnum * leidaxiao- 30, 7);   //控制label2的位置
            Form1.ActiveForm.Width = 30 + leidaxiao * xnum; //用于控制form窗体的宽度
            Form1.ActiveForm.Height = 130 + leidaxiao * ynum; //用于控制form窗体的高度
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fun2();
        }
    }
}
