﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace seven1
{
    public partial class Form1 : Form
    {
        private delegate void CALL(Control Tr);
        private Point mouseOffset;
        private bool isMouseDown = false;
        private bool IfThreadStart;
        private Thread T1;
        private Thread T2;
        private Thread T3;
        private Thread T4;
        private Thread T5;
        private Thread T6;
        public Form1()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;//加入这句话，不过治标不治本 
        }
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.mouseOffset = new Point(-e.X, -e.Y);
                this.isMouseDown = true;
            }
        }
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.isMouseDown = false;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (!this.IfThreadStart)
            {
                this.label7.Visible = false;
                InThread inThread = new InThread();
                inThread.SetNumber(this.label1, 1000);
                this.T1 = new Thread(new ThreadStart(inThread.RunInThread));
                this.T1.Start();
                InThread inThread2 = new InThread();
                inThread2.SetNumber(this.label2, 1111);
                this.T2 = new Thread(new ThreadStart(inThread2.RunInThread));
                this.T2.Start();
                InThread inThread3 = new InThread();
                inThread3.SetNumber(this.label3, 2222);
                this.T3 = new Thread(new ThreadStart(inThread3.RunInThread));
                this.T3.Start();
                InThread inThread4 = new InThread();
                inThread4.SetNumber(this.label4, 3333);
                this.T4 = new Thread(new ThreadStart(inThread4.RunInThread));
                this.T4.Start();
                InThread inThread5 = new InThread();
                inThread5.SetNumber(this.label5, 4444);
                this.T5 = new Thread(new ThreadStart(inThread5.RunInThread));
                this.T5.Start();
                InThread inThread6 = new InThread();
                inThread6.SetNumber(this.label6, 5555);
                this.T6 = new Thread(new ThreadStart(inThread6.RunInThread));
                this.T6.Start();
                this.IfThreadStart = true;
            }
            else
            {
                this.T1.Abort();
                this.T2.Abort();
                this.T3.Abort();
                this.T4.Abort();
                this.T5.Abort();
                this.T6.Abort();
                this.IfThreadStart = false;
                this.label7.Text =
					"海贼王中奖号码:"
					+this.label1.Text
                    + this.label2.Text
                    + this.label3.Text
                    + this.label4.Text
                    + this.label5.Text
                    + this.label6.Text;
                this.label7.Visible = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.IfThreadStart = false;
        }
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (this.isMouseDown)
            {
                Point mousePosition = Control.MousePosition;
                mousePosition.Offset(this.mouseOffset.X, this.mouseOffset.Y);
                base.Location = mousePosition;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            base.Close();
            Application.Exit();
        }
    }
}
