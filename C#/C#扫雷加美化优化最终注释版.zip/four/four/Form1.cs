﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Media;
using System.Threading;

namespace four
{
    public partial class Form1 : Form
    {
        private Button[,] dilei;//定义一个二维数组用于显示雷区
        private int xnum = 9;//初始化雷区的列数
        private int ynum = 9;//初始化雷去的行数
        public static int zdyxnum=9;//用于自定义中的列数
        public static int zdyynum=9;//用于自定义中的行数
        private int leinum = 10;//初始化第雷的总数
        public static int zdyleinum=10;//用于记录自定义中的雷数
        private int[,] turn;//-1 表示已经翻开；
        //0 表示没有翻开；1 表示插上了红期；
        public static int time1 = 0; //计量所用的时间
        private int time2 = 0; //初始化时间
        private int restlei = 10;//用于改变等级时载入剩余红旗数
        private int leidaxiao = 20;//控制雷块的大小
        public static string name = "海贼王";//玩家默认姓名
        private SoundPlayer player;//播放铃声用的
        public Form1()
        {
            InitializeComponent();//设计器初始化函数
        }

        private void 新游戏ToolStripMenuItem_Click(object sender, EventArgs e)
        {//新游戏对应的事件处理函数
            button1.Image = Image.FromFile("face.bmp");//给笑脸
            delall();//删除之前所有的雷区
            restlei = leinum;//剩余雷数赋值
            time1 = 0;//事件初始化为0
            label2.Text = time1.ToString();
            buleiqu();//布雷的一个函数
            youxiinit();//游戏初始化，很多参数的初始化
            timer1.Enabled = true;//启动定时器
        }
        private void delall() //删除所有的雷区
        {
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum; j++)   //二维数组逐个删除
                {
                    Button n = new Button();//定义一个新的button
                    n = (Button)dilei[i, j];//强制类型转换
                    this.Controls.Remove(dilei[i, j]);//删除所指雷区
                }
        }
        private void buleiqu()//布雷去，动态生成button
        {
            turn=new int[xnum,ynum];//记录状态的二维数组，开始为0；
            //表示未翻开,-1表示已翻开，1表示查了红旗
            dilei = new Button[xnum, ynum];//动态二维数组
            for(int i=0;i<xnum;i++)
                for (int j = 0; j < ynum; j++)
                {
                    dilei[i, j] = new Button();//西面是对生成
                    //每个button初始化，比如大小，字体，位置
                    this.Controls.Add(dilei[i, j]);
                    dilei[i, j].Left = 10 + leidaxiao * i;
                    dilei[i, j].Top = 65 + leidaxiao * j;
                    dilei[i, j].Width = leidaxiao;
                    dilei[i, j].Height = leidaxiao;
                    dilei[i, j].Font = new Font("宋体", 10.5F, 
                        FontStyle.Bold, GraphicsUnit.Point, ((byte)(134)));
                    dilei[i, j].BackgroundImageLayout = 
                        System.Windows.Forms.ImageLayout.Stretch;
                    dilei[i, j].Name = "lei" + (i + j*xnum).ToString();
                    dilei[i, j].MouseUp += new MouseEventHandler(fun1);   
                    dilei[i, j].Visible = true;   //控制Mines按钮的可见
                }
            bianform();//窗体初始化，这个是自动台藕节船体大熊啊和控件布局
        }
        private void youxiinit()  //游戏初始化
        {
            button2.Enabled = true;//启用作弊按钮
            restlei = leinum;
            label1.Text = restlei.ToString();
            for (int x = 0; x < xnum; x++)
                for (int y = 0; y < ynum; y++)//初始化，
                {
                    dilei[x, y].Text = "";
                    dilei[x, y].Visible = true;
                    dilei[x, y].Enabled = true;
                    dilei[x, y].Tag = null;
                    dilei[x, y].BackgroundImage = null;
                    turn[x, y] = 0;//刚开始都未插旗、表示为雷
                }
            bulei();//布雷。随机给雷区不上地雷
        }
        private void bulei() //布雷
        {
            int x, y;
            Random s = new Random();
            //取随机数
            for (int i = 0; i < leinum; )
            {
                //取随机数
                x = s.Next(xnum); //取随机数，
                //返回一个小于所指定最大值的非负随机数
                y = s.Next(ynum);
                if (Convert.ToInt16(dilei[x, y].Tag) != 1)
                {
                    //==1时，表示地雷
                    dilei[x, y].Tag = 1;//修改属性，用tag来存放的
                    i++;
                }
            }
            label1.Text = leinum.ToString();
            time1 = 0;//初始化时间
            label2.Text = time2.ToString();
        }
        private void fun1(object sender, MouseEventArgs e)//鼠标点击事件处理函数
        {//弹药分是左键还是邮件
            String btName;//button的名字
            Button bClick = (Button)sender;//拆箱
            btName = bClick.Name;
            int n = Convert.ToInt16(btName.Substring(3));//截取
            int x = n % xnum;
            int y = n / xnum;
            switch (e.Button)
            {
                case MouseButtons.Left://苏标左键
                    if (Convert.ToInt16(dilei[x, y].Tag) != 1)
                    {//没有踩到地雷
                        player.SoundLocation = "11.wav";//播放音乐
                        player.Load();
                        player.Play();
                        detpicture(GetAroundNum(x, y), x, y);//显示周围地雷总数
                        dilei[x, y].Enabled = false;//让他不可用
                        zhankailei(x, y);//对周围没有地雷的，对他周围的进项展开
                        if (turn[x, y]==1)//这是为了防止还有红旗插着就被锁了焦点，
                        {
                            dilei[x, y].Enabled = true;
                        }
                        if (Victory())//看看是不是赢了
                        {
                            player.SoundLocation = "4.wav";
                            player.Load();
                            player.Play();
                            MessageBox.Show("恭喜您，尼赢了!", "游戏结束");
                            timer1.Enabled = false;//停止计时
                            string s1 = name +":"+ label2.Text.ToString();
                            fun7(s1);//把记录写入文件
                            fun9();//让所有button都不可用
                        }
                    }
                    else
                    {//才到的是地雷
                        dilei[x, y].BackgroundImage = Image.FromFile("mine1.bmp");
                        button1.Image = Image.FromFile("face1.jpg");
                        player.SoundLocation = "a.wav";
                        player.Load();
                        player.Play();
                        MessageBox.Show("你才到地雷了!", "游戏结束");
                        fun3();
                        timer1.Enabled = false;//停止计时
                        fun9();//还是让所有的button都不可永
                    }
                    break;//跳出switch语句
                case MouseButtons.Right://惦记的是邮件
                    dilei[x, y].BackgroundImage = Image.FromFile("flag.bmp");
                    player.SoundLocation = "3.wav";
                            player.Load();
                            player.Play();
                    if (turn[x, y] == 1)//表示这个位置插上红旗
                    {
                        turn[x, y] = 0;//取消红旗,表示这个位置没有翻开
                        restlei++;//红旗书加1
                        dilei[x, y].BackgroundImage = null;
                    }
                    else
                    {
                        if (restlei > 0)//红旗书还有的话，才允许插红旗
                        {
                            turn[x, y] = 1;//表示这个位置插上红旗
                            restlei--;//红旗书减一
                        }
                        else
                        {
                            dilei[x, y].BackgroundImage = null;
                            MessageBox.Show("里的红旗用完了" );
                        }
                    }
                    label1.Text = restlei.ToString();
                    bool s=Victory();
                    //MessageBox.Show("Victory返回值是"+s.ToString(), "游戏结束");
                    if (Victory())
                    {
                        player.SoundLocation = "4.wav";
                        player.Load();
                        player.Play();
                        MessageBox.Show("恭喜您，尼赢了!", "游戏结束");
                        timer1.Enabled = false;//停止计时
                        string s1 = name + ":" + label2.Text.ToString();
                        fun7(s1);
                        fun9();
                    }
                    break;
            }
        }
        public void fun9()//让所有的button都不可用，改变他苏醒enable的知就好了
        {
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum; j++)
                    dilei[i, j].Enabled = false;
            button2.Enabled = false;
        }
        public static void fun7(string st)//将记录写入文件
        {
            FileStream fs = new FileStream(@".\re.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            //开始写入
            sw.Write("{0}\r\n",st);
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();
        }
        public static string fun8()//独处
        {
            StreamReader sr = new StreamReader(@".\re.txt", Encoding.Default);
            String line;
            string s1 = "";
            while ((line = sr.ReadLine()) != null)
            {
                s1 = s1 + line;
            }
            return s1;
        }
        private bool Victory()//判断是否赢了
        {//看看找出的地雷书是不是地雷总数
            //tag腰围1，状态要是1（插着红旗）
            int c1=0;
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum;j++)
                {
                    if (Convert.ToInt16(dilei[i, j].Tag) == 1
                        &&turn[i, j] == 1)
                        c1++;
                    //没翻开且未标示,则未成功
                    /*if (dilei[i, j].Enabled == true && turn[i, j] != 1)
                        return false;
                    //不是雷却误标示为雷,则也未成功
                    if (Convert.ToInt16(dilei[i, j].Tag) != 1
                        && turn[i,j] == 1)
                        return false;*/
                }
            if (c1 == leinum)//赢了就返回真
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void fun3()//将地图中所有雷标识出来
        {
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum; j++)
                    if (Convert.ToInt16(dilei[i, j].Tag) == 1)
                    {
                        //==1时，代表这个位置是地雷
                        player.SoundLocation = "a.wav";
                        player.Load();
                        player.Play();
                        Thread.Sleep(100);
                        dilei[i, j].BackgroundImage = Image.FromFile("mine1.bmp");
                    }
        }
        private void fun2()//将地图中所有雷标识出来
        {
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum; j++)
                    if (Convert.ToInt16(dilei[i, j].Tag) == 1)
                    {
                        //==1时，代表这个位置是地雷
                        dilei[i, j].BackgroundImage = Image.FromFile("mine.bmp");
                    }
        }
        private void detpicture(int n, int i, int j)//用于调用不同的图片
            //显示所单击按钮周围所剩的雷数
        {
            if (turn[i, j] != 1)//这个是为了防止那些查了红旗的不能用
            {
                turn[i, j] = -1;//改变他们的状态，-1表示已经被翻开
                switch (n)
                {
                    case 1:
                        {
                            dilei[i, j].BackgroundImage = Image.FromFile("1.PNG");
                            break;
                        }
                    case 2:
                        {
                            dilei[i, j].BackgroundImage = Image.FromFile("2.PNG");
                            break;
                        }
                    case 3:
                        {
                            dilei[i, j].BackgroundImage = Image.FromFile("3.PNG");
                            break;
                        }
                    case 4:
                        {
                            dilei[i, j].BackgroundImage = Image.FromFile("4.PNG");
                            break;
                        }
                    case 5:
                        {
                            dilei[i, j].BackgroundImage = Image.FromFile("5.PNG");
                            break;
                        }
                    case 6:
                        {
                            dilei[i, j].BackgroundImage = Image.FromFile("6.PNG");
                            break;
                        }
                    case 7:
                        {
                            dilei[i, j].BackgroundImage = Image.FromFile("7.PNG");
                            break;
                        }
                    case 8:
                        {
                            dilei[i, j].BackgroundImage = Image.FromFile("8.PNG");
                            break;
                        }
                }
            }
            else
            {
                dilei[i, j].Enabled = true;//查了红旗的可用
            }
        }
        private int GetAroundNum(int row, int col)//用于获取所单击按钮
            //周围8个雷块中所剩的雷数
        {
            int i, j;
            int aa = 0;//定义所生的雷数，开始为0
            int row1 = (row == 0) ? 0 : row - 1;//这是他旁边的8个
            int row2 = row + 2;
            int col1 = (col == 0) ? 0 : col - 1;
            int col2 = col + 2;
            for (i = row1; i < row2; i++)
            {
                for (j = col1; j < col2; j++) //[row,col]处没有雷
                {
                    if (!isinleiqu(i, j))   //判断是否在扫雷区域
                        continue;
                    if (Convert.ToInt16(dilei[i, j].Tag) == 1) aa++;
                }
            }
            return aa;   //返回所生的第雷数
        }
        private bool isinleiqu(int row, int col)   //判断是否已出雷区，
            //看看是否超界限了
        {
            return (row >= 0 && row < xnum 
                && col >= 0 && col < ynum);   //返回true or false
        }
        private void zhankailei(int row, int col)
        {//展开，如果他周围没砸蛋则对他周围的也翻开
            int i, j;
            int row1 = (row == 0) ? 0 : row - 1;
            int row2 = row + 2;
            int col1 = (col == 0) ? 0 : col - 1;
            int col2 = col + 2;
            int around =GetAroundNum(row, col);//对周围一个雷都没有的空白区域拓展
            if (around == 0)//周围没砸蛋
            {
                dilei[row, col].Enabled = false;//先让其不可用
                for (i = row1; i < row2; i++)
                {
                    for (j = col1; j < col2; j++)
                    {
                        //对于周围可以拓展的区域进行的规拓展			
                        if (!isinleiqu(i, j)) continue;
                        if (!(i == row && j == col) 
                            && dilei[i, j].Enabled != false)
                        {
                            zhankailei(i, j);//递归
                        }
                        dilei[i, j].Enabled = false; //周围无雷的区域按钮无效
                        detpicture(GetAroundNum(i, j), i, j);
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {//窗体进入的事件处理函数
            初级ToolStripMenuItem.Checked = true;   //使菜单中的初级可用
            loadlei();   //用于解决开始时单击任意按钮均胜利的问题
            youxiinit();    //游戏初始化
            fun9();//让所有的button不可用
            button2.Enabled = false;
            player = new SoundPlayer();
            player.SoundLocation = "6.wav";
            player.Load();
            player.Play();
            //timer1.Enabled = true;   //开启时钟计时
        }
        private void loadlei() //解决在开始时单击人一个按钮均会胜利的问题，
            //一下不做解释。
        {
            turn = new int[xnum, ynum];
            dilei = new Button[xnum, ynum];
            for (int i = 0; i < xnum; i++)
                for (int j = 0; j < ynum; j++)
                {
                    dilei[i, j] = new Button();
                    this.Controls.Add(dilei[i, j]);
                    dilei[i, j].Left = 10 + leidaxiao * i;
                    dilei[i, j].Top = 65 + leidaxiao * j;
                    dilei[i, j].Width = leidaxiao;
                    dilei[i, j].Height = leidaxiao;
                    dilei[i, j].Font = new Font("宋体", 10.5F,
                        FontStyle.Bold, GraphicsUnit.Point, ((byte)(134)));
                    dilei[i, j].BackgroundImageLayout =
                        System.Windows.Forms.ImageLayout.Stretch;
                    dilei[i, j].Name = "lei" + (i + j * xnum).ToString();
                    dilei[i, j].MouseUp += new MouseEventHandler(fun1);
                    dilei[i, j].Visible = true;   //控制Mines按钮的可见
                }
        }

        private void 初级ToolStripMenuItem_Click(object sender, EventArgs e)
        {//选择难度，所对应的雷区的行列数，和地雷数
            button1.Image = Image.FromFile("face.bmp");   //开始时，让button1按钮的Image设为face.bmp
            初级ToolStripMenuItem.Checked = true;   //初级按钮可用
            中级ToolStripMenuItem.Checked = false;   //中级按钮不可用
            高级ToolStripMenuItem.Checked = false;   //高级按钮不可用
            自定义ToolStripMenuItem.Checked = false;   //自定义按钮不可用
            delall();   //删除残余雷片
            xnum = 9;   //定义雷区的列数
            ynum = 9;   //定义雷区的行数
            leinum = 10;   //定义总雷数
            restlei = leinum;   //计数剩余的雷数
            label1.Text = time1.ToString();   //用于在开始界面显示所用的时间
            buleiqu(); //开始游戏
            youxiinit();//游戏初始化
            timer1.Enabled = true;   //触发计时器
            bianform();
        }

        private void 中级ToolStripMenuItem_Click(object sender, EventArgs e)
        {//选择难度，所对应的雷区的行列数，和地雷数
            button1.Image = Image.FromFile("face.bmp");   //开始时，让button1按钮的Image设为face.bmp
            初级ToolStripMenuItem.Checked = false;   //初级按钮可用
            中级ToolStripMenuItem.Checked = true;   //中级按钮不可用
            高级ToolStripMenuItem.Checked = false;   //高级按钮不可用
            自定义ToolStripMenuItem.Checked = false;   //自定义按钮不可用
            delall();   //删除残余雷片
            xnum = 16;   //定义雷区的列数
            ynum = 16;   //定义雷区的行数
            leinum = 40;   //定义总雷数
            restlei = leinum;   //计数剩余的雷数
            label1.Text = time1.ToString();   //用于在开始界面显示所用的时间
            buleiqu(); //开始游戏
            youxiinit();//游戏初始化
            timer1.Enabled = true;   //触发计时器
            bianform();
        }

        private void 高级ToolStripMenuItem_Click(object sender, EventArgs e)
        {//选择难度，所对应的雷区的行列数，和地雷数
            button1.Image = Image.FromFile("face.bmp");   //开始时，让button1按钮的Image设为face.bmp
            初级ToolStripMenuItem.Checked = false;   //初级按钮可用
            中级ToolStripMenuItem.Checked = false;   //中级按钮不可用
            高级ToolStripMenuItem.Checked = true;   //高级按钮不可用
            自定义ToolStripMenuItem.Checked = false;   //自定义按钮不可用
            delall(); //删除残余雷片
            xnum = 30; //定义雷区的列数
            ynum = 16;   //定义雷区的行数
            leinum = 99;   //定义总雷数
            restlei = leinum;   //计数剩余的雷数
            label1.Text = time1.ToString();   //用于在开始界面显示所用的时间
            buleiqu(); //开始游戏
            youxiinit();//游戏初始化
            timer1.Enabled = true;   //触发计时器
            bianform();
        }
        private void bianform()//决定form1的整体框架，改变窗体的大小和空念位置
        {
            button1.Location = new Point(-10 + xnum * leidaxiao / 2, -1); 
            //控制form1中的button1按钮开始的位置
            button2.Location = new Point(-25 + xnum * leidaxiao / 2, 65 
                + ynum * leidaxiao);//控制form1中的button2按钮开始的位置
            panel1.Size = new Size(30 + leidaxiao * xnum, 35);   //控制panel1的大小
            label2.Location = new Point(xnum * leidaxiao- 30, 7);   //控制label2的位置
            Form1.ActiveForm.Width = 30 + leidaxiao * xnum; //用于控制form窗体的宽度
            Form1.ActiveForm.Height = 130 + leidaxiao * ynum; //用于控制form窗体的高度
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fun2();//作弊按钮
        }

        private void timer1_Tick(object sender, EventArgs e)
        {//计时器事件处理函数，但记住intr这个属性药给1000，这样才是1秒
            time1++;
            label2.Text = time1.ToString();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {//退出，没什么说的吧
            Application.Exit();
        }

        private void 自定义ToolStripMenuItem_Click(object sender, EventArgs e)
        {//自定义
            Form3 f1 = new Form3();
            f1.ShowDialog();
            button1.Image = Image.FromFile("face.bmp");   //开始时，让button1按钮的Image设为face.bmp
            初级ToolStripMenuItem.Checked = false;   //初级按钮可用
            中级ToolStripMenuItem.Checked = false;   //中级按钮不可用
            高级ToolStripMenuItem.Checked = false;   //高级按钮不可用
            自定义ToolStripMenuItem.Checked = true;   //自定义按钮不可用
            delall();//删除残余的
            xnum = zdyxnum;   //定义雷区的列数
            ynum =zdyynum;   //定义雷区的行数
            leinum =zdyleinum;   //定义总雷数
            restlei = leinum;   //计数剩余的雷数
            label1.Text = time1.ToString();   //用于在开始界面显示所用的时间
            buleiqu(); //开始游戏
            youxiinit();//游戏初始化
            timer1.Enabled = true;   //触发计时器
            bianform();
        }

        private void 扫雷英雄榜ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 f1 = new Form4();
            f1.ShowDialog();
        }
         private void 关于扫雷ToolStripMenuItem1_Click(object sender, EventArgs e)
         {
             Form2 f1 = new Form2();
             f1.ShowDialog();
         }

         private void 关于游戏ToolStripMenuItem_Click(object sender, EventArgs e)
         {
             MessageBox.Show("本软件有海贼王编写\n计算机系软件技术4班\n1240610927白一泽");
         }

         private void 关于扫雷ToolStripMenuItem_Click(object sender, EventArgs e)
         {
             string s1 = "改游戏盒windows的很像\n玩法很简单";
             MessageBox.Show(s1);
         }
    }
}
