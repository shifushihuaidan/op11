﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace four
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        public static string fun8()//独处
        {
            StreamReader sr = new StreamReader(@".\re.txt", Encoding.Default);
            String line;
            string s1 = "";
            while ((line = sr.ReadLine()) != null)
            {
                s1 = s1 + line+"\r\n";
            }
            return s1;
        }
        private void Form4_Load(object sender, EventArgs e)
        {
            string s2 = fun8();
            textBox1.Text = s2;
        }
    }
}
