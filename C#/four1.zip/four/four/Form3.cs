﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace four
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string c1 = textBox1.Text;
            string c2 = textBox2.Text;
            string c3 = textBox3.Text;
            c1 = c1.Replace(" ", "");//并作出相应的处理
            c2 = c2.Replace(" ", "");//
            c3 = c3.Replace(" ", "");//
            string c4 = @"^-?\d+$"; //整数的模式 
            bool aa = System.Text.RegularExpressions.Regex.IsMatch(c1, c4);//匹配模式
            bool bb = System.Text.RegularExpressions.Regex.IsMatch(c1, c4);//匹配模式
            bool cc = System.Text.RegularExpressions.Regex.IsMatch(c1, c4);//匹配模式
            if (aa && bb && cc
                &&c1!=""&&c2!=""&&c3!="")
            {
                int dd=int.Parse(c1)*int.Parse(c2);
                if (int.Parse(c1) >= 9 && int.Parse(c1) <= 30
                    && int.Parse(c2) >= 9 && int.Parse(c1) <= 16
                    && int.Parse(c3) < dd)
                {
                    Form1.zdyxnum = int.Parse(c1);
                    Form1.zdyynum = int.Parse(c2);
                    Form1.zdyleinum = int.Parse(c3);
                    Form1.name = textBox4.Text.ToString();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("对不起，你设置的不合要球");
                }
            }
            else
            {
                MessageBox.Show("对不起，请输入正确的数字");//格式不正确就提示，重新输入
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
