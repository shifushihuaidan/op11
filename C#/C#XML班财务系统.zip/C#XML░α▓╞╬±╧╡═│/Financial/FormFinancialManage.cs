using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Financial
{
    public partial class FormFinancialManage : Form
    {
        public FormFinancialManage()
        {
            InitializeComponent();
        }

        private void FormFinancialManage_Load(object sender, EventArgs e)
        {

        }

        private void ToolStripMenuItem_AddIncome_Click(object sender, EventArgs e)
        {

        }

        private void ToolStripMenuItem_AddOutput_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton_Del_Click(object sender, EventArgs e)
        {

        }
    }
}