﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
#region
/*
 * 本程序有海贼王编写
 * 外号：海贼王 
 * 姓名：白一泽 计算机系软件技术4班
 * 更多请关注海贼王
 * 内容：C# ADO 操作数据库
 * 这么给打假说吧，不管哪种语言
 * 脸数据库无外乎三部；
 * 1，拿钥匙，
 * 2，开门
 * 3，操作
 * 4，关门
 * 在C#中，
 * 1，拿钥匙，就是创建数据库连接对象sqlconnection，当然了，jsp
 * 中还多了一部，因为jsp那要是的话，得先拿保险箱钥匙，
 * 也就是加载驱动，说多了，
 * 2，开门，就是打开连接，即使sqlconnection.open();
 * 3,操作，在C#中，借助sqlcommand
 * 他有3个方法excutenonquery()[用作insert，update，dekete
 * 这个返回该操作影响的行数]
 * excutescahar()[select，返回结果集中的第一行第一列，
 * 记住这里要拆想]
 * excutereader()[select,创建一个sqldatareader对象]
 * 然后你可以通过reader（）一行一行的读出
 * 
 * 这里谈到读数据，就得给大家详细说下了
 * 一行一行的读，或者制度一行，则使用sqldatareader 
 * 这个就没什么说的，一个while循环，家reader（）
 * 
 * 若全部读出，并显示，则借助
 * 空间datagrideview 数据库数据适配器sqldataadapter 
 * 数据集dataset  操作确定sqlcommandbuilder
 *通俗点说吧，数据适配器就好比是一个工厂，
 *而dataset就好比货车，datagrideview好比是广场
 *所以用这个方法的话，不用在乎原来工厂们是否凯泽，
 *但必须有这个钥匙，
 *尔广长战士的东西有事从货车里面哪的，
 *当你改了工厂的东西是，要通过货车去修稿原来工厂
 *里面的东西，怎么通知货车去改呢？当然就是
 *操作确定sqlcommandbuilder，然后da.update()就可以了，
 * 但要记住的是
 * 这个update（），只有当货车里面东西变了的时候，货车财货
 * 送货到原来工厂
 * ，所以要记得修改状态，
 * 
 * 4,关门，也就是关闭连接，sqlconnection.close();
*/
#endregion
namespace ADO连接数据库
{
    public partial class Form1 : Form
    {//窗体类
        //数据库数据适配器
        private SqlDataAdapter da=new SqlDataAdapter();
        //数据集，其实这里都可以不用数据集，用数据表就好了
        private DataSet ds=new DataSet();
        //数据表
        private DataTable dt = new DataTable();
        //操作确定
        private SqlCommandBuilder cb;
        public Form1()
        {
            InitializeComponent();//设计器初始化函数
            
        }

        private void button1_Click(object sender, EventArgs e)
        {//事件处理函数
            try
            {
                //定义数据库连接字符串
                //string s1 = "Data Source=.;uid=sa;pwd=079444;database=test";
                string s1 = "Data Source=.;integrated security=true;database=test";
                SqlConnection con = new SqlConnection(s1);//创建数据库连接对象
                con.Open();//打开连接
                
                //定义相关sql语句，
                /*
                string sql = "insert into op values(12,'乔巴','医生')";
                //string sql="delete from op where id=12";
                //string sql = "update op set name='大牛' where id=12";
                
                //定义sqlcommand对象操作数据库
                SqlCommand com = new SqlCommand(sql, con);
                //给适配器相应的命令的command对象
                //da.UpdateCommand = com;
                //da.SelectCommand=com
                da.InsertCommand = com;
                //da.DeleteCommand = com;
                da.Fill(dt);//填充数据表
                foreach (DataRow dr in dt.Rows)
                {//改变状态，这里的要和上面的两个
                    //对应，一定要记住，不然会错
                    //dr.Delete();break;
                    dr.SetAdded();break;
                    //dr.SetModified();break;
                }
                */


               //下面是另一种，更实用的快速的方法
               //就是先对货车的datatable更新，然后再
                //送去原工厂

                //da.Fill(dt);//填充数据表，记住这一句必须在其他之前

                /*  //修改操作
                int i = dataGridView1.CurrentRow.Index;
                DataRow dr = dt.Rows[i];
                dr.BeginEdit();
                dr[1] = "大铁锤";
                dr.EndEdit();
                 */

                /*//删除操作
                int i = dataGridView1.CurrentRow.Index;
                DataRow dr = dt.Rows[i];
                dr.Delete();
                
                 */

                /*//插入操作
                 * DataRow dr1 = dt.NewRow();
                dr1[0] = 125;
                dr1[1] = "黑胡子";
                dr1[2] = "当海贼王";
                dt.Rows.Add(dr1);
                 */
                //da.Update(dt);//更新数据库
                dataGridView1.DataSource = dt;//让该空间显示表类容
                con.Close();//关闭连接
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //下面的就没什么好解释的了,
        private void button2_Click(object sender, EventArgs e)
        {
            string s1 = "Data Source=.;uid=sa;pwd=079444;database=test";
            //string s2 = "Data Source=.;integrated security=true;database=op";
            SqlConnection con = new SqlConnection(s1);
            con.Open();
            string sql = "select * from op";
            SqlCommand com = new SqlCommand(sql, con);
            cb = new SqlCommandBuilder(da);
            da.SelectCommand = com;
            ds.Clear();
            da.Fill(ds, "tab1");
            dataGridView1.DataSource=ds.Tables["tab1"];
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            da.Update(dt);//更新数据库
        }
    }
}
