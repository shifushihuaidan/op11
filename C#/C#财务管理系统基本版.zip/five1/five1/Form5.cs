﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace five1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            comboBox1.Text = comboBox1.Items[1].ToString();//默认选中第一个值
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                //MessageBox.Show("用户名和密码不为空");
                int i =Form4.dataGridView1.CurrentRow.Index;
                DataRow dr =Form1.dt.Rows[i];
                dr.BeginEdit();
                dr[1] =textBox1.Text;
                dr[2] = textBox2.Text;
                if (comboBox1.Text == "是")
                {
                    dr[3] = 1;
                }
                else 
                {
                    dr[3] = 0;
                }
                dr.EndEdit();
                Form4.dataGridView1.DataSource = Form1.dt;
                this.Close();
            }
            else
            {
                MessageBox.Show("用户名和密码不能为空");
            }
        }
    }
}
