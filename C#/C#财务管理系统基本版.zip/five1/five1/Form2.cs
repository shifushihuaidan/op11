﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace five1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.ToString() != "" 
                && textBox2.Text.ToString() != ""
                    && textBox3.Text.ToString() != "")
            {
                if (textBox2.ToString() == textBox3.ToString())
                {
                    //MessageBox.Show("密码相同");
                    //插入操作
                     DataRow dr1 =Form1.dt.NewRow();
                    dr1[1] = textBox1.Text;
                    dr1[2] = textBox2.Text;
                    Form1.dt.Rows.Add(dr1);
                    Form4.dataGridView1.DataSource = Form1.dt;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("对不起，两次密码输入不一致");
                }
            }
            else 
            {
                MessageBox.Show("对不起，用户名和密码不能为空");
            }
        }
    }
}
