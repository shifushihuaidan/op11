﻿using System;//引入名字命名空间
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace seven1
{
    #region
    /*
     * 本系统由海贼王编写
     * 
     * 姓名：白一泽 1240610927 计算机系软件技术4班
     * 
     * 主要西乡：
     * 就是不规则的窗提，并且可拖动的；
     * 
     * 然后县城的操作而已
     * 
     * 然后加了一点扩展，就是写入文件，读出文件
     * 
     */
    #endregion
    public partial class Form1 : Form
    {
        private delegate void CALL(Control Tr);//定义委托
        private Point mouseOffset;//定义一变量，后面拖动要用
        private bool isMouseDown = false;
        private bool IfThreadStart;//这个也是后面要用而假的
        private Thread T1;//定义县城
        private Thread T2;
        private Thread T3;
        private Thread T4;
        private Thread T5;
        private Thread T6;
        public Form1()
        {
            InitializeComponent();//设计器函数调用
            Control.CheckForIllegalCrossThreadCalls = false;//加入这句话，
            //不过治标不治本 ，因为C#默认不允许在控件的非创建线程中设置控件的值
        }
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {//事件处理函数
            if (e.Button == MouseButtons.Left)
            {
                this.mouseOffset = new Point(-e.X, -e.Y);
                this.isMouseDown = true;
            }
        }
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {//事件处理函数，鼠标
            if (e.Button == MouseButtons.Left)
            {
                this.isMouseDown = false;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {//事件处理函数，让6个label同事县数字，且变化
            if (!this.IfThreadStart)
            {
                this.label7.Visible = false;//让label7不想死
                InThread inThread = new InThread();
                inThread.SetNumber(this.label1, 1000);
                this.T1 = new Thread(new ThreadStart(inThread.RunInThread));
                this.T1.Start();
                InThread inThread2 = new InThread();
                inThread2.SetNumber(this.label2, 1111);
                this.T2 = new Thread(new ThreadStart(inThread2.RunInThread));
                this.T2.Start();
                InThread inThread3 = new InThread();
                inThread3.SetNumber(this.label3, 2222);
                this.T3 = new Thread(new ThreadStart(inThread3.RunInThread));
                this.T3.Start();
                InThread inThread4 = new InThread();
                inThread4.SetNumber(this.label4, 3333);
                this.T4 = new Thread(new ThreadStart(inThread4.RunInThread));
                this.T4.Start();
                InThread inThread5 = new InThread();
                inThread5.SetNumber(this.label5, 4444);
                this.T5 = new Thread(new ThreadStart(inThread5.RunInThread));
                this.T5.Start();
                InThread inThread6 = new InThread();
                inThread6.SetNumber(this.label6, 5555);
                this.T6 = new Thread(new ThreadStart(inThread6.RunInThread));
                this.T6.Start();
                this.IfThreadStart = true;
            }
            else
            {
                this.T1.Abort();
                this.T2.Abort();
                this.T3.Abort();
                this.T4.Abort();
                this.T5.Abort();
                this.T6.Abort();
                this.IfThreadStart = false;
                this.label7.Text =
					"海贼王中奖号码:"
					+this.label1.Text
                    + this.label2.Text
                    + this.label3.Text
                    + this.label4.Text
                    + this.label5.Text
                    + this.label6.Text;
                fun7(this.label7.Text);
                this.label7.Visible = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {//窗体加载事件处理函数
            this.IfThreadStart = false;
        }
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {//事件处理程序
            if (this.isMouseDown)
            {
                Point mousePosition = Control.MousePosition;
                mousePosition.Offset(this.mouseOffset.X, this.mouseOffset.Y);
                base.Location = mousePosition;
            }
        }

        public static void fun7(string st)//将记录写入文件
        {
            FileStream fs = new FileStream(@".\re.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            //开始写入
            sw.Write("{0}\r\n", st);
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();
        }
        public static string fun8()//独处
        {
            StreamReader sr = new StreamReader(@".\re.txt", Encoding.Default);
            String line;
            string s1 = "";
            while ((line = sr.ReadLine()) != null)
            {
                s1 = s1 + line;
            }
            return s1;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {//退出
            DialogResult result = MessageBox.Show("您确定要退出吗？",
              "退出", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            if (result == DialogResult.OK)
            {
                //执行OK的代码
                base.Close();
                Application.Exit();
            }
            else
            {
                //执行Cancel的代码
            } 
        }
    }
}
