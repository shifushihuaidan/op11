using System;
using System.Collections.Generic;
using System.Xml;
namespace MyCinema
{
	[Serializable]
	public class Schedule
	{
		private Dictionary<string, ScheduleItem> items;
		public Dictionary<string, ScheduleItem> Items
		{
			get
			{
				return this.items;
			}
			set
			{
				this.items = value;
			}
		}
		public Schedule()
		{
			this.items = new Dictionary<string, ScheduleItem>();
		}
		public void LoadItems()
		{
			if (this.items == null)
			{
				this.items = new Dictionary<string, ScheduleItem>();
			}
			this.items.Clear();
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load("ShowList.xml");
			XmlNode documentElement = xmlDocument.DocumentElement;
			string movieName = null;
			string poster = null;
			string director = null;
			string actor = null;
			string value = null;
			string s = null;
			foreach (XmlNode xmlNode in documentElement.ChildNodes)
			{
				if (xmlNode.Name == "Movie")
				{
					foreach (XmlNode xmlNode2 in xmlNode.ChildNodes)
					{
						string name = xmlNode2.Name;
						switch (name)
						{
						case "Name":
							movieName = xmlNode2.InnerText;
							break;
						case "Poster":
							poster = xmlNode2.InnerText;
							break;
						case "Director":
							director = xmlNode2.InnerText;
							break;
						case "Actor":
							actor = xmlNode2.InnerText;
							break;
						case "Type":
							value = xmlNode2.InnerText;
							break;
						case "Price":
							s = xmlNode2.InnerText;
							break;
						case "Schedule":
							foreach (XmlNode xmlNode3 in xmlNode2.ChildNodes)
							{
								ScheduleItem scheduleItem = new ScheduleItem();
								scheduleItem.Time = xmlNode3.InnerText;
								scheduleItem.Movie.MovieName = movieName;
								scheduleItem.Movie.Poster = poster;
								scheduleItem.Movie.Director = director;
								scheduleItem.Movie.Actor = actor;
								scheduleItem.Movie.MovieType = (MovieType)Enum.Parse(typeof(MovieType), value);
								scheduleItem.Movie.Price = int.Parse(s);
								this.items.Add(scheduleItem.Time, scheduleItem);
							}
							break;
						}
					}
				}
			}
		}
	}
}
