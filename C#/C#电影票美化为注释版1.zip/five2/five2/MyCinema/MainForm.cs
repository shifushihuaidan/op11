using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
namespace MyCinema
{
    #region
    /*
     本系统又海贼王编写
     * 姓名：白一泽 1240610927 计算机系软件技术4班
     * 本项目主要思想：
     * 无外乎XML的操作，再加点序列化而已，没什么说的
     * 由于本次时间仓储，没有时间写详细的注释了
     * 想要注释的朋友可以私下找我，我到时写好注释传给你
     * 而且本次的项目代码太多，所以没写注释，忘各位见谅
     * 也没加什么扩展，
     */
    #endregion

    public partial class MainForm : Form
	{
		
		public MainForm()
		{
			this.InitializeComponent();
		}
		private void MainForm_Load(object sender, EventArgs e)
		{
			this.lblActor.Text = "";
			this.lblDirector.Text = "";
			this.lblMovieName.Text = "";
			this.lblPrice.Text = "";
			this.lblTime.Text = "";
			this.lblType.Text = "";
			this.lblCalcPrice.Text = "";
			this.txtCustomer.Enabled = false;
			this.cmbDisCount.Enabled = false;
			this.rdoNormal.Checked = true;
			this.cinema = new Cinema();
			this.InitSeats(7, 5, this.tpCinema);
			this.cinema.Load();
		}
		private void InitSeats(int seatRow, int seatLine, TabPage tb)
		{
			for (int i = 0; i < seatRow; i++)
			{
				for (int j = 0; j < seatLine; j++)
				{
					Label label = new Label();
					label.BackColor = Color.Yellow;
					label.AutoSize = false;
					label.Font = new Font("宋体", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 134);
					label.Location = new Point(59, 60);
					label.Name = "lbl" + (j + 1).ToString() + "_" + (i + 1).ToString();
					label.Size = new Size(50, 25);
					label.Text = (j + 1).ToString() + "-" + (i + 1).ToString();
					label.TextAlign = ContentAlignment.MiddleCenter;
					label.Location = new Point(60 + i * 90, 60 + j * 60);
					label.Click += new EventHandler(this.lblSeat_Click);
					tb.Controls.Add(label);
					this.labels.Add(label.Text, label);
					Seat seat = new Seat((j + 1).ToString() + "-" + (i + 1).ToString(), Color.Yellow);
					this.cinema.Seats.Add(seat.SeatNum, seat);
				}
			}
		}
		private void tsmiMovies_Click(object sender, EventArgs e)
		{
			if (this.cinema.Schedule.Items.Count == 0)
			{
				this.cinema.Schedule.LoadItems();
			}
			this.InitTreeView();
		}
		private void tsmiNew_Click(object sender, EventArgs e)
		{
			this.cinema.Schedule.LoadItems();
			this.cinema.SoldTickets.Clear();
			this.InitTreeView();
		}
		private void InitTreeView()
		{
			this.tvMovies.BeginUpdate();
			this.tvMovies.Nodes.Clear();
			string a = null;
			TreeNode treeNode = null;
			foreach (ScheduleItem current in this.cinema.Schedule.Items.Values)
			{
				if (a != current.Movie.MovieName)
				{
					treeNode = new TreeNode(current.Movie.MovieName);
					this.tvMovies.Nodes.Add(treeNode);
				}
				TreeNode node = new TreeNode(current.Time);
				treeNode.Nodes.Add(node);
				a = current.Movie.MovieName;
			}
			this.tvMovies.EndUpdate();
		}
		private void tvMovies_AfterSelect(object sender, TreeViewEventArgs e)
		{
			TreeNode selectedNode = this.tvMovies.SelectedNode;
			if (selectedNode != null)
			{
				if (selectedNode.Level == 1)
				{
					this.key = selectedNode.Text;
					this.lblMovieName.Text = this.cinema.Schedule.Items[this.key].Movie.MovieName;
					this.lblDirector.Text = this.cinema.Schedule.Items[this.key].Movie.Director;
					this.lblActor.Text = this.cinema.Schedule.Items[this.key].Movie.Actor;
					this.lblPrice.Text = this.cinema.Schedule.Items[this.key].Movie.Price.ToString();
					this.lblTime.Text = this.cinema.Schedule.Items[this.key].Time;
					this.lblType.Text = this.cinema.Schedule.Items[this.key].Movie.MovieType.ToString();
					this.picMovie.Image = Image.FromFile(this.cinema.Schedule.Items[this.key].Movie.Poster);
					this.lblCalcPrice.Text = "";
					this.ClearSeat();
					foreach (Ticket current in this.cinema.SoldTickets)
					{
						foreach (Seat current2 in this.cinema.Seats.Values)
						{
							if (current.ScheduleItem.Time == this.key && current.Seat.SeatNum == current2.SeatNum)
							{
								current2.Color = Color.Red;
							}
						}
					}
					this.UpdateSeat();
				}
			}
		}
		private void ClearSeat()
		{
			foreach (Seat current in this.cinema.Seats.Values)
			{
				current.Color = Color.Yellow;
			}
		}
		private void UpdateSeat()
		{
			foreach (string current in this.cinema.Seats.Keys)
			{
				this.labels[current].BackColor = this.cinema.Seats[current].Color;
			}
		}
		private void lblSeat_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(this.lblMovieName.Text))
			{
				MessageBox.Show("您还没选择电影");
			}
			else
			{
				this.ticket++;
				try
				{
					string text = ((Label)sender).Text.ToString();
					string customerName = this.txtCustomer.Text.ToString();
					int discount = 0;
					string type = "";
					if (this.rdoStudent.Checked)
					{
						type = "student";
						if (this.cmbDisCount.Text == null)
						{
							MessageBox.Show("请输入折扣数");
							return;
						}
						discount = int.Parse(this.cmbDisCount.Text);
					}
					else
					{
						if (this.rdoFree.Checked)
						{
							if (string.IsNullOrEmpty(this.txtCustomer.Text))
							{
								MessageBox.Show("请输入赠票者姓名");
								return;
							}
							type = "free";
						}
					}
					Ticket ticket = TicketFactory.CreateTicket(this.cinema.Schedule.Items[this.key], this.cinema.Seats[text], discount, customerName, type);
					if (this.cinema.Seats[text].Color == Color.Yellow)
					{
						DialogResult dialogResult = MessageBox.Show("是否购买?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
						if (dialogResult == DialogResult.Yes)
						{
							this.cinema.Seats[text].Color = Color.Red;
							this.UpdateSeat();
							this.cinema.SoldTickets.Add(ticket);
							ticket.CalcPrice();
							this.lblCalcPrice.Text = ticket.Price.ToString();
							ticket.Print();
						}
						else
						{
							if (dialogResult == DialogResult.No)
							{
							}
						}
					}
					else
					{
						MessageBox.Show("已售出.");
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}
		}
		private void rdoVip_CheckedChanged(object sender, EventArgs e)
		{
			this.txtCustomer.Enabled = true;
			this.cmbDisCount.Enabled = false;
			this.cmbDisCount.Text = "";
		}
		private void rdoStudent_CheckedChanged(object sender, EventArgs e)
		{
			this.txtCustomer.Enabled = false;
			this.txtCustomer.Text = "";
			this.cmbDisCount.Enabled = true;
			this.cmbDisCount.Text = "5";
		}
		private void rdoNormal_CheckedChanged(object sender, EventArgs e)
		{
			this.cmbDisCount.Enabled = false;
			this.txtCustomer.Text = "";
			this.txtCustomer.Enabled = false;
			this.cmbDisCount.Text = "";
		}
		private void tsmiExit_Click(object sender, EventArgs e)
		{
			this.cinema.Save();
			base.Dispose();
		}
		private void tsmiSave_Click(object sender, EventArgs e)
		{
            DialogResult result = MessageBox.Show("您确定要保存吗吗？",
              "会大印出信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            if (result == DialogResult.OK)
            {
                //执行OK的代码
                this.cinema.Save();
            }
            else
            {
                //执行Cancel的代码
            }
			
		}
		private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show("是否保存当前销售状态?", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
			if (dialogResult == DialogResult.Yes)
			{
				this.cinema.Save();
			}
		}

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string s1 = "欢迎进入海贼王影院";
            MessageBox.Show(s1);
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string s1 = "本系统有海贼王编写\n姓名：白一泽 1240610927\n更多请关注海贼王白一泽";
            MessageBox.Show(s1);
        }
		
	}
}
