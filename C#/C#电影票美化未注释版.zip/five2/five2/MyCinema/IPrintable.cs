using System;
namespace MyCinema
{
	public interface IPrintable
	{
		void Print();
	}
}
