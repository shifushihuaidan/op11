using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace MyCinema
{
	public class Cinema
	{
		private Dictionary<string, Seat> seats;
		private Schedule schedule;
		private List<Ticket> soldTickets;
		public Dictionary<string, Seat> Seats
		{
			get
			{
				return this.seats;
			}
			set
			{
				this.seats = value;
			}
		}
		public Schedule Schedule
		{
			get
			{
				return this.schedule;
			}
			set
			{
				this.schedule = value;
			}
		}
		public List<Ticket> SoldTickets
		{
			get
			{
				return this.soldTickets;
			}
			set
			{
				this.soldTickets = value;
			}
		}
		public Cinema()
		{
			this.seats = new Dictionary<string, Seat>();
			this.soldTickets = new List<Ticket>();
			this.schedule = new Schedule();
		}
		public void Save()
		{
			FileStream fileStream = new FileStream("soldTickets.bin", FileMode.Create);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.Serialize(fileStream, this.SoldTickets);
			fileStream.Close();
		}
		public void Load()
		{
			try
			{
				FileStream fileStream = new FileStream("soldTickets.bin", FileMode.Open);
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				this.SoldTickets = (List<Ticket>)binaryFormatter.Deserialize(fileStream);
				fileStream.Close();
			}
			catch (Exception ex)
			{
				ex.ToString();
				this.soldTickets = new List<Ticket>();
			}
		}
	}
}
