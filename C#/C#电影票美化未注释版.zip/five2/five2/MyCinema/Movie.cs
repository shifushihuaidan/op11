using System;
namespace MyCinema
{
	[Serializable]
	public class Movie
	{
		private string movieName;
		private string poster;
		private string director;
		private string actor;
		private MovieType movieType;
		private int price;
		public string MovieName
		{
			get
			{
				return this.movieName;
			}
			set
			{
				this.movieName = value;
			}
		}
		public string Poster
		{
			get
			{
				return this.poster;
			}
			set
			{
				this.poster = value;
			}
		}
		public string Director
		{
			get
			{
				return this.director;
			}
			set
			{
				this.director = value;
			}
		}
		public string Actor
		{
			get
			{
				return this.actor;
			}
			set
			{
				this.actor = value;
			}
		}
		public MovieType MovieType
		{
			get
			{
				return this.movieType;
			}
			set
			{
				this.movieType = value;
			}
		}
		public int Price
		{
			get
			{
				return this.price;
			}
			set
			{
				this.price = value;
			}
		}
		public Movie()
		{
		}
		public Movie(string movieName, string poster, string director, string actor, MovieType movieType, int price)
		{
			this.MovieName = movieName;
			this.Poster = poster;
			this.Director = director;
			this.Actor = actor;
			this.MovieType = movieType;
			this.Price = price;
		}
	}
}
