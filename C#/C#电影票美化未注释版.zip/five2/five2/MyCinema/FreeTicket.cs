using System;
using System.IO;
namespace MyCinema
{
	[Serializable]
	public class FreeTicket : Ticket, IPrintable
	{
		private string customerName;
		public string CustomerName
		{
			get
			{
				return this.customerName;
			}
			set
			{
				this.customerName = value;
			}
		}
		public FreeTicket()
		{
		}
		public FreeTicket(ScheduleItem scheduleItem, Seat seat, string customerName) : base(scheduleItem, seat)
		{
			this.CustomerName = customerName;
		}
		public override void CalcPrice()
		{
			base.Price = 0;
		}
		public override void Print()
		{
			string path = base.ScheduleItem.Time + " " + base.Seat.SeatNum + ".txt";
			FileStream fileStream = new FileStream(path, FileMode.Create);
			StreamWriter streamWriter = new StreamWriter(fileStream);
			streamWriter.WriteLine("***************************");
			streamWriter.WriteLine("     海贼王影院 (赠票)");
			streamWriter.WriteLine("---------------------------");
			streamWriter.WriteLine(" 电影名：\t{0}", base.ScheduleItem.Movie.MovieName);
			streamWriter.WriteLine(" 时间：\t{0}", base.ScheduleItem.Time);
			streamWriter.WriteLine(" 座位号：\t{0}", base.Seat.SeatNum);
			streamWriter.WriteLine(" 姓名：\t{0}", this.CustomerName);
			streamWriter.WriteLine("***************************");
			streamWriter.Close();
			fileStream.Close();
		}
	}
}
