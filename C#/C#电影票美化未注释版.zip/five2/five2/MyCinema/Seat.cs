using System;
using System.Drawing;
namespace MyCinema
{
	[Serializable]
	public class Seat
	{
		private string seatNum;
		private Color color;
		public string SeatNum
		{
			get
			{
				return this.seatNum;
			}
			set
			{
				this.seatNum = value;
			}
		}
		public Color Color
		{
			get
			{
				return this.color;
			}
			set
			{
				this.color = value;
			}
		}
		public Seat(string seatNum, Color color)
		{
			this.SeatNum = seatNum;
			this.Color = color;
		}
	}
}
