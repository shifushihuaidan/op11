﻿using System;//引入名字命名空间
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
namespace three//声明名字命名空间
{
   
//#region
    /*作者： 白一泽
     * 别名：海贼王
     * 该项目主要思想
     * 点击新游戏时，先给16个picturebox对应数组的ims赋初始值，
     * 1-8,0号我要用来做反转的图，所以从1开始，9张图片存放在imagelist中，
     * 分两次随机给16各元素分配，保证16个元素都有值，且之不同，8对，
     * 然后与imagelist对应，
     *比对的时候，要注意两个条件，1，两次点击不能一样，2，两次点击的拓片
     *对应的值要一样才配对陈宫，
     * 其他的就没什么说的了
     */
//#endregion
    public partial class Form1 : Form//窗体类
    {
        private int[] ims;//数组，用来存放16个值，里面放1-8，
                              //也就是说每个数字有两个空间在存放着
        private int a1;//点击第一个图片,存放期tag
        private int a2;//点击第二个图片，存放其位置，tag
        private int b11;//点击的第一张图片的值，存放期所对因的值，1-8
        private int b2;//点击第二张图片，存放期所对因的值，1-8
        private int count = 0;//计数，点击的次数
        private int t1=0;//3秒翻转
        //private int[] bb;//存放索引
        //private int[] b1;
        private int t2=0;//配对不陈宫，翻转，0.5s翻一次
        private int c1=1;//控制定时器t2，这好似程序中要用才加的
        private int t3 = 0;//已用时间，当钱玩家已花时间
        private int red;//最高纪录，时间最短的
        private int duishu=0;//匹配对数，一共8对，
        private int d1 = 0;//后面加的，主要用来作为暂停，继续和作弊的
                           //点击事件处理函数的
        public Form1()//够着函数
        {
            InitializeComponent();//设计器函数
            ims = new int[16];//数组春石化，开16个空间
            //bb = new int[16];
           // b1 = new int[16];
            fun9();//调用fun9（）函数，让所有图片控件暂时无法用
        }

        private void 游戏归责ToolStripMenuItem_Click(object sender, EventArgs e)
        {//游戏规则，对引的事件处理函数
            Form2 f2 = new Form2();//定义一个form2窗体类，在模式弹出，
            f2.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {//退出，有几种对应的方法退出
            //base.Close();
            //this.Close();
            Application.Exit();
        }
        private void fun10()//初始化，各计时器
        {
            timer1.Enabled = timer2.Enabled = timer3.Enabled = false;
            t1 = t2 = t3=0;
        }
        private void 新游戏ToolStripMenuItem_Click(object sender, EventArgs e)
        {//新游戏对应的事件处理函数
            fun10();//调用函数fun10（）初始化计时器
            duishu = 0;//对数初始化
            d1 = 1;//d1赋值，这样才好控制暂停，继续，作弊
            int i1 = 0;//新加的
            for (int i = 0; i < ims.Length; i++)//for循环，给数组赋值
            { 
                ims[i]=-1;//赋值为-1，你也可以给其它的值，但不要是1-8；
            }
            for (int j = 1; j <= 8; j++)//for循环，1-8，装入数组
            {
                fun(j);//点用函数，随机装值
                fun(j);
            }
            foreach (Control c1 in base.Controls)//foreach，便利图片控件
            {
                if (c1 is PictureBox)
                {
                    
                    /*bb[i1] = Convert.ToInt32(((PictureBox)c1).Tag);
                    b1[i1]=ims[bb[i1]];
                    ((PictureBox)c1).Visible = true;
                    ((PictureBox)c1).Image=imageList1.Images[b1[i1]];*/
                    int bb = Convert.ToInt32(((PictureBox)c1).Tag);//tag是对象，不要用int.parse，
                    int b1 = ims[bb];//获取里面村的值，1-8；
                    ((PictureBox)c1).Visible = true;
                    ((PictureBox)c1).Enabled = false;//设置不可用
                    ((PictureBox)c1).Image = imageList1.Images[b1];//显示到picturebox
                    i1++;
                }
            }
            timer1.Enabled = true;//大翻转定时器开始
           // MessageBox.Show("当前t1为{0}",t1.ToString());
           /* if (t1 == 3)
            {
                fun1();
                timer1.Enabled =false;
                t1 = 0;
            }*/
           /* i1 = 0;
            foreach (Control c1 in base.Controls)
            {
                if (c1 is PictureBox)
                {
                    ((PictureBox)c1).Visible = false;
                    ((PictureBox)c1).Image = imageList1.Images[b1[i1]];
                    i1++;
                }
            }*/
            timer3.Enabled = true;//记录已用时间计时器开始计时
        }
        private void fun1()//翻转图片
        {
            foreach (Control c1 in base.Controls)//还是循环，给每张图片显示0号
            {
                if (c1 is PictureBox)
                {
                    ((PictureBox)c1).Image = imageList1.Images[0];
                }
            }
        }
        private void fun(int i)//1-8赋值给16元素的函数
        {
            Random r1 = new Random();//随机数类
            int aa = r1.Next(16);//产生一个小余16的非负整数
            if (ims[aa] != -1)//判断是否幼稚了
            {
                while (ims[aa] != -1)//循环赋值
                {
                    aa = r1.Next(16);
                }
            }
            ims[aa] = i;
        }
        private void fun3(int a)//将指定的图片，设为不见
        {
            foreach (Control item in this.Controls)//还是循环而已
            {
                if (item is PictureBox)
                {
                    if (Convert.ToInt32(((PictureBox)item).Tag) == a)
                    {
                        ((PictureBox)item).Visible = false;//不可见
                    }
                }
            }

        }
        private void fun4(int aa,int bb)//设置其他图片不可点击,除开两指定图片
        {
            foreach (Control item in this.Controls)
            {
                if (item is PictureBox)
                {
                    for (int i = 0; i < 16; i++)
                    {
                        if ((Convert.ToInt32(((PictureBox)item).Tag) != aa)&&
                            (Convert.ToInt32(((PictureBox)item).Tag) != bb))//记住一定是与哦
                        {
                            ((PictureBox)item).Enabled = false;
                        }
                    }
                }
            }
        }
        private void fun5()//设置其他图片可点击
        {
            foreach (Control item in this.Controls)
            {
                if (item is PictureBox)
                {
                    ((PictureBox)item).Enabled = true;        
                }
            }
        }
        private void fun9()//设置其他图片不可点击
        {
            foreach (Control item in this.Controls)
            {
                if (item is PictureBox)
                {
                    ((PictureBox)item).Enabled = false;
                }
            }
        }
        private void fun6()//判断是否赢了，赢了就弹出对话
        {
            if (duishu == 8)//8对，就试完了结了
            {
                duishu = 0;//对数初始为0，能避免bug
                d1 = 0;//d1为0，暂停，继续，作弊不可用
                timer3.Enabled = false;
                if (red > t3)//判断是否破了纪录
                {
                    red = t3;//破了的话，就更新记录
                    fun7(t3.ToString());//写入文件，覆盖写
                    //timer3.Enabled = false;
                    t3 = 0;//t3计时器初始化
                    MessageBox.Show("你破记录了,恭喜");
                    label1.Text = "最高纪录:" + red + "秒";//更新最高记录
                }
                else
                {
                    MessageBox.Show("配对完成,用时" + t3.ToString());//弹出成绩
                }
            }
        }
        public static void fun7(string st)//将记录写入文件
        {
            FileStream fs = new FileStream(@".\re.txt", FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            //开始写入
            sw.Write(st);
            //清空缓冲区
            sw.Flush();
            //关闭流
            sw.Close();
            fs.Close();
        }
        public static string fun8()//独处最高纪录
        {
            StreamReader sr = new StreamReader(@".\re.txt", Encoding.Default);
            String line;
            string s1 = "";
            while ((line = sr.ReadLine()) != null)
            {
                s1 = s1 + line;
            }
            return s1;
        }
        private void pictureBox1_Click(object sender, EventArgs e)//图片点击事件
        {
            count += 1;//点击次数佳佳
            if (count == 1)//第一次点击
            {
                 a1 =Convert.ToInt32(((PictureBox)sender).Tag);
                 b11 =ims[a1];
                 ((PictureBox)sender).Image = imageList1.Images[b11];//显示图片
            }
            if(count==2)//第二次点击
            {
                a2 = Convert.ToInt32(((PictureBox)sender).Tag);
                b2 = ims[a2];
                fun4(a1, a2);//设置其他图片不可点击
                ((PictureBox)sender).Image = imageList1.Images[b2];//拆箱
                if (a1!=a2&&b11 == b2)
                {
                    //MessageBox.Show("配对成功");
                    //Thread.Sleep(1000);
                    duishu++;//对数加加
                    fun3(a1);//置顶图片消失
                    fun3(a2);//指定图片消失
                    fun5();//设置其他图片可点击
                }
                else
                {
                    c1 = 0;//计时器t2函数的条件，赋值
                    timer2.Enabled = true;//t2计时器开始计时
                    //fun1();//翻转
                }
                count = 0;//次数记录归零
            }
            fun6();//判断对数，看是否结束
        }

        private void timer1_Tick(object sender, EventArgs e)//计时器事件处理函数
        {
            t1++;
            if (t1 == 3)//3秒，我设置的interval为1000，所以为3秒
            {
                fun1();//翻转
                timer1.Enabled = false;//计时器停用
                t1 = 0;//计时器归零
                foreach (Control c1 in base.Controls)//foreach循环，各图片可用
                {
                    if (c1 is PictureBox)
                    {
                        ((PictureBox)c1).Enabled = true;//拆箱
                    }
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)//计时器t2事件处理函数
        {
            if (c1 == 0)//不配对的条件变量
            {
                t2++;//计时器加1，就是
                if (t2 == 1)//0.5s

                {
                    fun1();//翻转
                    timer2.Enabled = false;
                    fun5(); //设置其他图片可点击
                    t2 = 0;//t2归零
                }
            }
        }

        private void timer3_Tick(object sender, EventArgs e)//t3事件处理函数
        {
            t3++;
            string cc="已用时：";//记录已用时间
            label2.Text = cc + t3.ToString() + "秒";
        }

        private void Form1_Load(object sender, EventArgs e)//窗体加载事件处理函数
        {
            /*string ss = "100";
            fun7(ss);*/
            string s2 = fun8();//读出文件
            label1.Text ="最高纪录:"+ s2+"秒";
            red = int.Parse(s2);//赋值给red
        }

        private void 暂停ToolStripMenuItem_Click(object sender, EventArgs e)
        {//暂停事件处理函数
            if (d1 == 1)
            {
                timer2.Enabled = false;//t2,t3计时器停用
                timer3.Enabled = false;
                fun9();//设置其他图片不可点击，以免误操做
                d1 = 2;//继续，条件控制
            }
        }

        private void 继续ToolStripMenuItem_Click(object sender, EventArgs e)
        {//继续事件处理函数
            if (d1 == 2)
            {
                timer2.Enabled = true;//t2,t3计时器停用
                timer3.Enabled = true;
                fun5();//设置其他图片可点击
            }
            d1 = 1;
        }

        private void 作弊ToolStripMenuItem_Click(object sender, EventArgs e)
        {//作弊事件处理函数
            if (d1==1)//天剑变量
            {
                Random r2=new Random();//随见舒蕾
                int a4=r2.Next(8);//产生随机数
                for (int j = 0; j < 16; j++)//for循环给16有图片赋值
                {
                    ims[j] = a4;//附一个值
                }
            }
        }
    }
}
