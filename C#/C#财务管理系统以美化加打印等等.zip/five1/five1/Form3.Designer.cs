﻿namespace five1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStripMain = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItem_System = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Writeoff = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Switch = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Financial = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_IncomeManage = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_DebitManage = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_Statistic = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Manage = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_DataInput = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_DataOutput = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Help = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_HelpTheme = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_About = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStripMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("宋体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(214, 126);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 66);
            this.button1.TabIndex = 0;
            this.button1.Text = "收支管理";
            this.toolTip1.SetToolTip(this.button1, "收入和支出的情况管理");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseLeave += new System.EventHandler(this.button1_MouseLeave);
            this.button1.MouseHover += new System.EventHandler(this.button1_MouseHover);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(29, 252);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(137, 70);
            this.button2.TabIndex = 1;
            this.button2.Text = "借贷管理";
            this.toolTip1.SetToolTip(this.button2, "借出和贷款的情况管理");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            this.button2.MouseLeave += new System.EventHandler(this.button2_MouseLeave);
            this.button2.MouseHover += new System.EventHandler(this.button2_MouseHover);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(29, 126);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(123, 66);
            this.button3.TabIndex = 3;
            this.button3.Text = "用户管理";
            this.toolTip1.SetToolTip(this.button3, "管理员对用户进行管理");
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            this.button3.MouseLeave += new System.EventHandler(this.button3_MouseLeave);
            this.button3.MouseHover += new System.EventHandler(this.button3_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("叶根友毛笔行书2.0版", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(23, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(285, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "海贼王财务管理系统";
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(214, 252);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(123, 66);
            this.button4.TabIndex = 4;
            this.button4.Text = "信息查询";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            this.button4.MouseLeave += new System.EventHandler(this.button4_MouseLeave);
            this.button4.MouseHover += new System.EventHandler(this.button4_MouseHover);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(29, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 14);
            this.label2.TabIndex = 6;
            this.label2.Text = "label2";
            // 
            // menuStripMain
            // 
            this.menuStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_System,
            this.ToolStripMenuItem_Financial,
            this.ToolStripMenuItem_Manage,
            this.ToolStripMenuItem_Help});
            this.menuStripMain.Location = new System.Drawing.Point(0, 0);
            this.menuStripMain.Name = "menuStripMain";
            this.menuStripMain.Size = new System.Drawing.Size(466, 25);
            this.menuStripMain.TabIndex = 7;
            this.menuStripMain.Text = "menuStrip1";
            // 
            // ToolStripMenuItem_System
            // 
            this.ToolStripMenuItem_System.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Writeoff,
            this.ToolStripMenuItem_Switch,
            this.toolStripSeparator1,
            this.ToolStripMenuItem_Exit});
            this.ToolStripMenuItem_System.Name = "ToolStripMenuItem_System";
            this.ToolStripMenuItem_System.Size = new System.Drawing.Size(59, 21);
            this.ToolStripMenuItem_System.Text = "系统(&S)";
            // 
            // ToolStripMenuItem_Writeoff
            // 
            this.ToolStripMenuItem_Writeoff.Name = "ToolStripMenuItem_Writeoff";
            this.ToolStripMenuItem_Writeoff.Size = new System.Drawing.Size(152, 22);
            this.ToolStripMenuItem_Writeoff.Text = "注销帐户(&W)";
            this.ToolStripMenuItem_Writeoff.Click += new System.EventHandler(this.ToolStripMenuItem_Writeoff_Click);
            // 
            // ToolStripMenuItem_Switch
            // 
            this.ToolStripMenuItem_Switch.Name = "ToolStripMenuItem_Switch";
            this.ToolStripMenuItem_Switch.Size = new System.Drawing.Size(152, 22);
            this.ToolStripMenuItem_Switch.Text = "切换帐户(&S)";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // ToolStripMenuItem_Exit
            // 
            this.ToolStripMenuItem_Exit.Name = "ToolStripMenuItem_Exit";
            this.ToolStripMenuItem_Exit.Size = new System.Drawing.Size(152, 22);
            this.ToolStripMenuItem_Exit.Text = "退出(&E)";
            this.ToolStripMenuItem_Exit.Click += new System.EventHandler(this.ToolStripMenuItem_Exit_Click);
            // 
            // ToolStripMenuItem_Financial
            // 
            this.ToolStripMenuItem_Financial.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_IncomeManage,
            this.ToolStripMenuItem_DebitManage,
            this.toolStripSeparator3,
            this.ToolStripMenuItem_Statistic});
            this.ToolStripMenuItem_Financial.Name = "ToolStripMenuItem_Financial";
            this.ToolStripMenuItem_Financial.Size = new System.Drawing.Size(83, 21);
            this.ToolStripMenuItem_Financial.Text = "个人理财(&P)";
            // 
            // ToolStripMenuItem_IncomeManage
            // 
            this.ToolStripMenuItem_IncomeManage.Name = "ToolStripMenuItem_IncomeManage";
            this.ToolStripMenuItem_IncomeManage.Size = new System.Drawing.Size(141, 22);
            this.ToolStripMenuItem_IncomeManage.Text = "收支管理(&I)";
            // 
            // ToolStripMenuItem_DebitManage
            // 
            this.ToolStripMenuItem_DebitManage.Name = "ToolStripMenuItem_DebitManage";
            this.ToolStripMenuItem_DebitManage.Size = new System.Drawing.Size(141, 22);
            this.ToolStripMenuItem_DebitManage.Text = "借贷管理(&D)";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(138, 6);
            // 
            // ToolStripMenuItem_Statistic
            // 
            this.ToolStripMenuItem_Statistic.Name = "ToolStripMenuItem_Statistic";
            this.ToolStripMenuItem_Statistic.Size = new System.Drawing.Size(141, 22);
            this.ToolStripMenuItem_Statistic.Text = "统计(&S)";
            // 
            // ToolStripMenuItem_Manage
            // 
            this.ToolStripMenuItem_Manage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator2,
            this.ToolStripMenuItem_DataInput,
            this.ToolStripMenuItem_DataOutput});
            this.ToolStripMenuItem_Manage.Name = "ToolStripMenuItem_Manage";
            this.ToolStripMenuItem_Manage.Size = new System.Drawing.Size(88, 21);
            this.ToolStripMenuItem_Manage.Text = "系统维护(&M)";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(149, 6);
            // 
            // ToolStripMenuItem_DataInput
            // 
            this.ToolStripMenuItem_DataInput.Name = "ToolStripMenuItem_DataInput";
            this.ToolStripMenuItem_DataInput.Size = new System.Drawing.Size(152, 22);
            this.ToolStripMenuItem_DataInput.Text = "数据导入(&I)";
            // 
            // ToolStripMenuItem_DataOutput
            // 
            this.ToolStripMenuItem_DataOutput.Name = "ToolStripMenuItem_DataOutput";
            this.ToolStripMenuItem_DataOutput.Size = new System.Drawing.Size(152, 22);
            this.ToolStripMenuItem_DataOutput.Text = "数据导出(&O)";
            // 
            // ToolStripMenuItem_Help
            // 
            this.ToolStripMenuItem_Help.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_HelpTheme,
            this.ToolStripMenuItem_About});
            this.ToolStripMenuItem_Help.Name = "ToolStripMenuItem_Help";
            this.ToolStripMenuItem_Help.Size = new System.Drawing.Size(61, 21);
            this.ToolStripMenuItem_Help.Text = "帮助(&H)";
            // 
            // ToolStripMenuItem_HelpTheme
            // 
            this.ToolStripMenuItem_HelpTheme.Name = "ToolStripMenuItem_HelpTheme";
            this.ToolStripMenuItem_HelpTheme.Size = new System.Drawing.Size(152, 22);
            this.ToolStripMenuItem_HelpTheme.Text = "帮助主题(&T)";
            this.ToolStripMenuItem_HelpTheme.Click += new System.EventHandler(this.ToolStripMenuItem_HelpTheme_Click);
            // 
            // ToolStripMenuItem_About
            // 
            this.ToolStripMenuItem_About.Name = "ToolStripMenuItem_About";
            this.ToolStripMenuItem_About.Size = new System.Drawing.Size(152, 22);
            this.ToolStripMenuItem_About.Text = "关于(&A)";
            this.ToolStripMenuItem_About.Click += new System.EventHandler(this.ToolStripMenuItem_About_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(466, 365);
            this.Controls.Add(this.menuStripMain);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "主界面";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.menuStripMain.ResumeLayout(false);
            this.menuStripMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStripMain;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_System;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Writeoff;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Switch;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Exit;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Financial;
        internal System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_IncomeManage;
        internal System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_DebitManage;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Statistic;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Manage;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_DataInput;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_DataOutput;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Help;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_HelpTheme;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_About;
    }
}