﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace five1
{
    public partial class Form7 : Form
    {
        public static int a1;
        public Form7()
        {
            InitializeComponent();
            //MessageBox.Show(a1.ToString());
            comboBox1.Text = comboBox1.Items[0].ToString();//默认选中第一个值
            comboBox2.Text = comboBox2.Items[1].ToString();//默认选中第一个值
            comboBox3.Text = comboBox3.Items[0].ToString();//默认选中第一个值
            comboBox4.Text = comboBox4.Items[1].ToString();//默认选中第一个值
            switch(a1)
            {
                case 0:
                panel1.Visible = true;
                panel2.Visible = false;
                break;
                case 1:
                panel1.Visible = true;
                panel2.Visible = true;
                panel3.Visible = false;
                break;
                case 2:
                panel1.Visible = true;
                panel2.Visible = true;
                panel3.Visible = true;
                panel4.Visible = false;
                break;
                case 3:
                panel1.Visible = true;
                panel2.Visible = true;
                panel3.Visible = true;
                panel4.Visible = true;
                break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                //MessageBox.Show("用户名和密码不为空");
                int i = Form6.dataGridView1.CurrentRow.Index;
                DataRow dr1 = Form1.dt2.NewRow();     
                dr1[1] = comboBox1.Text;
                dr1[2] = dateTimePicker1.Text;
                dr1[3] = textBox1.Text;
                dr1[4] = textBox2.Text;
                Form1.dt2.Rows.Add(dr1);
                Form6.dataGridView1.DataSource = Form1.dt2;
                this.Close();
            }
            else
            {
                MessageBox.Show("金额不能为空");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox4.Text != "" )
            {
                //MessageBox.Show("用户名和密码不为空");
                int i = Form6.dataGridView1.CurrentRow.Index;
                DataRow dr = Form1.dt2.Rows[i];
                dr.BeginEdit();
                dr[1] = comboBox2.Text;
                dr[2] = dateTimePicker2.Text;
                dr[3] = textBox4.Text;
                dr[4] = textBox3.Text;
                dr.EndEdit();
                Form6.dataGridView1.DataSource = Form1.dt2;
                this.Close();
            }
            else
            {
                MessageBox.Show("金额不能为空");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox5.Text != "" && textBox6.Text != ""
                && textBox7.Text != "")
            {
                //MessageBox.Show("用户名和密码不为空");
                int i = Form8.dataGridView1.CurrentRow.Index;
                DataRow dr1 = Form1.dt3.NewRow();
                dr1[1] = comboBox3.Text;
                dr1[2] =textBox5.Text;
                dr1[3] =textBox6.Text ;
                dr1[4] = dateTimePicker3.Text;
                dr1[5] = textBox7.Text;
                Form1.dt3.Rows.Add(dr1);
                Form8.dataGridView1.DataSource = Form1.dt3;
                this.Close();
            }
            else
            {
                MessageBox.Show("姓名,金额,期限不能为空");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox8.Text != "" && textBox9.Text != ""
               && textBox10.Text != "")
            {
                //MessageBox.Show("用户名和密码不为空");
                int i = Form8.dataGridView1.CurrentRow.Index;
                DataRow dr1 = Form1.dt3.Rows[i];
                dr1.BeginEdit();
                dr1[1] = comboBox4.Text;
                dr1[2] = textBox8.Text;
                dr1[3] = textBox9.Text;
                dr1[4] = dateTimePicker4.Text;
                dr1[5] = textBox10.Text;
                dr1.EndEdit();
                Form8.dataGridView1.DataSource = Form1.dt3;
                this.Close();
            }
            else
            {
                MessageBox.Show("姓名,金额,期限不能为空");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == '.' || e.KeyChar == 8))
            {
                e.Handled = true;
            }
        }
    }
}
