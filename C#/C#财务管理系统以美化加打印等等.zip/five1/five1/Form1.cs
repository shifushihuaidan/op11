﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Media;

namespace five1
{
    public partial class Form1 : Form
    {
        Bitmap bmpText;
        public static SqlConnection con;
        public static string shenfen = "普通用户";
        public static SqlDataAdapter da = new SqlDataAdapter();
        //数据集，其实这里都可以不用数据集，用数据表就好了
        public static DataSet ds = new DataSet();
        //数据表
        public static DataTable dt1 = new DataTable();
        public static DataTable dt2 = new DataTable();
        public static DataTable dt3 = new DataTable();
        //操作确定
        public static SqlCommandBuilder cb;
        public static  SoundPlayer player;//播放铃声用的
        public Form1()
        {
            InitializeComponent();
            player = new SoundPlayer();
            using (Font fnt = new Font("Arial", 25, FontStyle.Bold))
            {
                this.bmpText = (Bitmap)FancyText.ImageFromText("海贼王财务管理系统", fnt, Color.Green, Color.Goldenrod);
            }

            this.pictureBox_Title.Image = this.bmpText;
            this.timer1.Start();
        }

        private void b_yes_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                string sql = "select count(*) from user1 where name= '" + textBox1.Text + "'";
                SqlCommand com = new SqlCommand(sql, con);
                int n = (int)com.ExecuteScalar();
                if (n==0)
                {
                    MessageBox.Show("对不起用户名不存在");
                    player.SoundLocation = "a.wav";
                    player.Load();
                    player.Play();
                }
                else
                {
                    sql += " and mima= '" + textBox2.Text + "'";
                    com.CommandText = sql;
                    n = (int)com.ExecuteScalar();
                    if (n ==0)
                    {
                        MessageBox.Show("密码错误");
                        player.SoundLocation = "3.wav";
                        player.Load();
                        player.Play();
                    }
                    else
                    {
                        player.SoundLocation = "6.wav";
                        player.Load();
                        player.Play();
                        sql = "select * from user1 where name= '" + textBox1.Text + "'";
                        //MessageBox.Show(sql);
                        sql += " and mima= '" + textBox2.Text + "'";
                        com.CommandText = sql;
                        SqlDataReader reader = com.ExecuteReader();
                        if(reader.Read())
                        {
                            //MessageBox.Show(reader["name"].ToString());
                            if ((int)reader["admi"]==1)
                            {
                                //MessageBox.Show("你是管理员");
                                reader.Close();
                                shenfen = "管理员";
                                this.Hide();
                                Form3 f1 = new Form3();
                                f1.ShowDialog();
                            }
                            else
                            {
                                //MessageBox.Show("你是普通人员");
                                reader.Close();
                                this.Hide();
                                Form3 f1 = new Form3();
                                f1.ShowDialog(); 
                            }
                            this.Show();
                        }
                    }
                }
                //con.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
                con.Close();
            }
        }

        private void b_no_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string s2 = "Data Source=.;integrated security=true;database=op";
            con = new SqlConnection(s2);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rand = new Random();
            Color clr1 = Color.FromArgb(rand.Next(255), rand.Next(255), rand.Next(255));
            Color clr2 = Color.FromArgb(rand.Next(255), rand.Next(255), rand.Next(255));
            using (Font fnt = new Font("Arial", 25, FontStyle.Bold))
            {
                this.bmpText = (Bitmap)FancyText.ImageFromText("海贼王财务管理系统", fnt, clr1, clr2);
            }

            this.pictureBox_Title.Image = this.bmpText;
        }
    }
}
