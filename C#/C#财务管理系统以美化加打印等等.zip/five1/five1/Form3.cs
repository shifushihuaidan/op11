﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace five1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 f1 = new Form4();
            f1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 f1 = new Form6();
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 f1 = new Form8();
            f1.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form9 f1 = new Form9();
            f1.ShowDialog();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            if (Form1.shenfen == "管理员")
            {
                button3.Enabled = button1.Enabled =
                    button1.Enabled = button4.Enabled =
                    true;
                //label2.Text ="当前身份："+ Form1.shenfen;
            }
            else
            {
                button3.Enabled = false;
            }
            label2.Text = "当前身份：" + Form1.shenfen;
        }

        private void ToolStripMenuItem_Exit_Click(object sender, EventArgs e)
        {
            if (Form1.con.State == ConnectionState.Open)
            {
                Form1.con.Close();
            }
            Application.Exit();
        }

        private void ToolStripMenuItem_Writeoff_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        private void ToolStripMenuItem_HelpTheme_Click(object sender, EventArgs e)
        {
            MessageBox.Show("本系统适合装有sqlsever的用户使用");
        }

        private void ToolStripMenuItem_About_Click(object sender, EventArgs e)
        {
            MessageBox.Show("本系统优海贼王编写"+"\n姓名:白一泽\n更多请关注海贼王");
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
           button3.Size = new Size(170,90);
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.Size = new Size(123, 66);
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.Size = new Size(170, 90);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.Size = new Size(123, 66);
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.Size = new Size(170, 90);
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.Size = new Size(123, 66);
        }

        private void button4_MouseHover(object sender, EventArgs e)
        {
            button4.Size = new Size(170, 90);
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            button4.Size = new Size(123,66);
        }
    }
}
