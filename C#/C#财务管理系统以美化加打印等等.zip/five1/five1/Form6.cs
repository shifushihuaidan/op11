﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;

namespace five1
{
    public partial class Form6 : Form
    {
        //private int a1 = 0;
        //private int a2 = 0;
        //private int a3 = 0;
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            string sql = "select * from shouzhi";
            SqlCommand com = new SqlCommand(sql, Form1.con);
            Form1.cb = new SqlCommandBuilder(Form1.da);
            Form1.da.SelectCommand = com;
            Form1.dt2.Clear();
            Form1.ds.Clear();
            Form1.da.Fill(Form1.dt2);
            dataGridView1.DataSource = Form1.dt2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("您确定要更新吗？",
              "会更新数据库信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            if (result == DialogResult.OK)
            {
                //执行OK的代码
                Form1.da.Update(Form1.dt2);
                Form6_Load(this, e);
            }
            else
            {
                //执行Cancel的代码
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 添加用户ToolStripMenuItem_Click(object sender, EventArgs e)
        { 
            Form7.a1=0;
            //MessageBox.Show("前面a1是：" + Form7.a1.ToString());
            Form7 f1 = new Form7();
            f1.ShowDialog();
        }

        private void 修改用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7.a1 = 1;
            Form7 f1 = new Form7();
            f1.ShowDialog();
        }

        private void 删除该用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("您确定要删除吗？",
                  "暂时不会更新数据库信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            if (result == DialogResult.OK)
            {
                //执行OK的代码
                int i = dataGridView1.CurrentRow.Index;
                DataRow dr = Form1.dt2.Rows[i];
                dr.Delete();
            }
            else
            {
                //执行Cancel的代码
            }
        }

        private void ToolStripMenuItem_HelpTheme_Click(object sender, EventArgs e)
        {
            MessageBox.Show("本系统适合装有sqlsever的用户使用");
        }

        private void ToolStripMenuItem_About_Click(object sender, EventArgs e)
        {
            MessageBox.Show("本系统优海贼王编写" + "\n姓名:白一泽\n更多请关注海贼王");
        }

        private void ToolStripMenuItem_DataInput_Click(object sender, EventArgs e)
        {//打印
            PrintDGV.Print_DataGridView(dataGridView1);
        }

        private void ToolStripMenuItem_NomalCal_Click(object sender, EventArgs e)
        {
            //Process.Start(@"海贼王简易计算器1.exe");
            //if (a1 == 0 && a2 == 0)
            //{
                Process.Start(@"海贼王计算器.exe");
               /* a1 = 1;
                a2 = 1;
            }
            else
            {
                MessageBox.Show("你已经打开");
            }*/
        }

        private void ToolStripMenuItem_ProfressionalCal_Click(object sender, EventArgs e)
        {
            //Process.Start(@"海贼王计算器.exe");
            //if (a1 == 1 && a3 == 0)
            //{
                Process.Start(@"海贼王简易计算器1.exe");
                /*a1 = 0;
                a3 = 1;
            }*/
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //select * from shouzhi where DATEDIFF(day,'2013-11-3',dtime) >0 
            //and DATEDIFF(day,dtime ,'2014-11-7') >0 
            //MessageBox.Show(dateTimePicker1.Text);
            string sql = "select * from shouzhi where DATEDIFF(day,'";
            sql+=dateTimePicker1.Value+"',dtime) >0 ";
            sql += "and DATEDIFF(day,dtime ,'" +dateTimePicker2.Value+ "') >0";
            SqlCommand com = new SqlCommand(sql, Form1.con);
            Form1.cb = new SqlCommandBuilder(Form1.da);
            Form1.da.SelectCommand = com;
            Form1.dt2.Clear();
            Form1.ds.Clear();
            Form1.da.Fill(Form1.dt2);
            dataGridView1.DataSource = Form1.dt2;
        }
    }
}
