﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace five1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("您确定要更新吗？",
              "会更新数据库信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            if (result == DialogResult.OK)
            {
                //执行OK的代码
                Form1.da.Update(Form1.dt3);
                Form8_Load(this, e);
            }
            else
            {
                //执行Cancel的代码
            }
        }

        private void 添加用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7.a1 = 2;
            //MessageBox.Show("前面a1是：" + Form7.a1.ToString());
            Form7 f1 = new Form7();
            f1.ShowDialog();
        }

        private void 修改用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7.a1 = 3;
            Form7 f1 = new Form7();
            f1.ShowDialog();
        }

        private void 删除该用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("您确定要删除吗？",
                  "暂时不会更新数据库信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            if (result == DialogResult.OK)
            {
                //执行OK的代码
                int i = dataGridView1.CurrentRow.Index;
                DataRow dr = Form1.dt3.Rows[i];
                dr.Delete();
            }
            else
            {
                //执行Cancel的代码
            }
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            string sql = "select * from jiedai";
            SqlCommand com = new SqlCommand(sql, Form1.con);
            Form1.cb = new SqlCommandBuilder(Form1.da);
            Form1.da.SelectCommand = com;
            Form1.dt3.Clear();
            Form1.ds.Clear();
            Form1.da.Fill(Form1.dt3);
            dataGridView1.DataSource = Form1.dt3;
        }
    }
}
