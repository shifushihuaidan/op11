/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package op.bean;
/**
 *
 * @author Administrator
 */
public class Course {
    private Integer id;
    private String cid;
    private String cname;
    private int count;
    public Course() {
    }

    public Course(Integer id) {
        this.id = id;
    }

    public Course(Integer id, String cid, String cname, int count) {
        this.id = id;
        this.cid = cid;
        this.cname = cname;
        this.count = count;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
