/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package op.bean;
/**
 *
 * @author Administrator
 */
public class User {
    private Integer id;
    private String uid;
    private String uname;
    private String umima;
    private int shenfen;
    public User() {
    }

    public User(Integer id) {
        this.id = id;
    }

    public User(Integer id, String uid, String umima, int shenfen) {
        this.id = id;
        this.uid = uid;
        this.umima = umima;
        this.shenfen = shenfen;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUmima() {
        return umima;
    }

    public void setUmima(String umima) {
        this.umima = umima;
    }

    public int getShenfen() {
        return shenfen;
    }

    public void setShenfen(int shenfen) {
        this.shenfen = shenfen;
    }
}
