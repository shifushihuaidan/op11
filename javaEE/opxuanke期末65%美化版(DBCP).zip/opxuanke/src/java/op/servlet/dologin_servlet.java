/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package op.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import op.bean.User;
import op.dbconn.DbConn;

/**
 *
 * @author Administrator
 */
public class dologin_servlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            //out.print("登陆处理");
            request.setCharacterEncoding("utf-8");
            String id=request.getParameter("uid");
            String mima=request.getParameter("mima");
            //out.print(id+"<br>");
            //out.print(mima+"<br>");
            DbConn db=new DbConn();
            Connection con=db.get_connection();
            String sql="select * from user where uid=?";
            PreparedStatement prest=con.prepareStatement(sql);
            prest.setString(1, id);
            ResultSet rs=prest.executeQuery();
            HttpSession session=request.getSession();
            if(rs.next())
            {
                if(rs.getString("umima").equals(mima))
                {
                    //RequestDispatcher rd=request.getRequestDispatcher("1.jsp");
                    //rd.forward(request, response);
                    //out.print("<script>alert('登录成功');</script>");
                    if(rs.getInt("shenfen")==1)
                    {
                        session.setAttribute("uid",id);
                        User userbean1=new User();
                        userbean1.setUid(id);
                        userbean1.setUname(rs.getString("uname"));
                        userbean1.setUmima(mima);
                        session.setAttribute("userbean",userbean1);
                        response.sendRedirect("index1_servlet");
                        //out.print("<script>alert('你是管理员');</script>");
                        //out.print("<script>window.location='admin1/index1.jsp'</script>");
                    }
                    else if(rs.getInt("shenfen")==0)
                    {
                        //out.print("<script>alert('你是学生');</script>");
                        //RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/xuanke.jsp");
                        //rd.forward(request, response);
                        session.setAttribute("uid",id);
                        sql="select * from student where sid=?";
                        prest=con.prepareStatement(sql);
                        prest.setString(1, id);
                        rs=prest.executeQuery();
                        User userbean=new User();
                        if(rs.next())
                        {
                            userbean.setUname(rs.getString("sname"));
                            userbean.setUid(rs.getString("sid"));
                            //out.print(userbean.getUname());
                        }
                        //User userbean=new User();
                        //userbean.setUname();
                        /*rs.close();
                        prest.close();
                        con.close();*/
                        //out.print("<script>alert('测试看看');");
                        session.setAttribute("userbean",userbean);
                        response.sendRedirect("xuanke_servlet");
                        //response.sendRedirect("yixuanke_servlet");
                    }
                    else
                    {
                        //out.print("<script>alert('你是教师');</script>");
                        //RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/xuanke.jsp");
                        //rd.forward(request, response);
                        session.setAttribute("uid",id);
                        sql="select * from teacher where tid=?";
                        prest=con.prepareStatement(sql);
                        prest.setString(1, id);
                        rs=prest.executeQuery();
                        User userbean=new User();
                        if(rs.next())
                        {
                            userbean.setUname(rs.getString("name"));
                            userbean.setUid(rs.getString("tid"));
                            //out.print(userbean.getUname());
                        }
                        //User userbean=new User();
                        //userbean.setUname();
                        /*rs.close();
                        prest.close();
                        con.close();*/
                        //out.print("<script>alert('测试看看');");
                        session.setAttribute("userbean",userbean);
                        response.sendRedirect("teacher_servlet3");
                        //response.sendRedirect("yixuanke_servlet");
                    }
                }
                else
                {
                    //;window.location='2.jsp'
                    out.print("<script>alert('登录失败，密码错误');"
                            + "window.location='login.jsp'</script>");
                    //response.sendRedirect("login.jsp");
                }
            }
            else
            {
                out.print("<script>alert('登录失败，账号不存在');"
                        + "window.location='login.jsp'</script>");
                //response.sendRedirect("login.jsp");
            }
            //out.print("<script>alert('测试看看');");
            rs.close();
            prest.close();
            con.close();
            
        }
        catch(SQLException se)
        {
            //se.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
