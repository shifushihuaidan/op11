/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package op.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import op.bean.User;
import op.dbconn.DbConn;

/**
 *
 * @author Administrator
 */
public class doxuanke_servlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String cid=request.getParameter("cid");
            int count=Integer.parseInt( request.getParameter("count"));
            //String count=request.getParameter("count");
            if(count>0)
            {
            //out.print("课程号是"+cid);
            String sid;
            HttpSession session=request.getSession();
            User user=(User)session.getAttribute("userbean");
            sid=user.getUid();
            //out.print("<br>学号是"+sid);
            String sql="insert into sc(sid,cid) values(?,?)";
            DbConn db=new DbConn();
            Connection con=db.get_connection();
            PreparedStatement prest=con.prepareStatement(sql);
            prest.setString(1,sid);
            prest.setString(2,cid);
            //int i=prest.executeUpdate();
            //out.print("<script>alert('"+i+"')</script>");
            if(prest.executeUpdate()==1)
            {
                sql="update course set count=count-1 where cid=?";
                prest=con.prepareStatement(sql);
                prest.setString(1,cid);
                prest.executeUpdate();
                out.print("<script>alert('选课成功');"
                            + "window.location='xuanke.jsp'</script>");
            }
            else
            {
                out.print("<script>alert('选课失败');"
                            + "window.location='xuanke.jsp'</script>");
            }
            prest.close();
            con.close();
            
            }
            else
            {
                out.print("<script>alert('该课已选玩了');"
                            + "window.location='xuanke.jsp'</script>");
            }
            
        }
       catch(SQLException se)
        {
            //response.sendRedirect("xuanke.jsp");
            PrintWriter out = response.getWriter();
            out.println( se.toString()+"</br>");
            //se.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
