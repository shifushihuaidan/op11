/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package op.dbconn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 *
 * @author Administrator
 */
public class DbConn {
    /*private final String driver1="com.mysql.jdbc.Driver";
    private final String url1="jdbc:mysql://localhost:3306/xuanke";
    private final String user="root";
    private final String password="root";*/
    private static Context context;
    private static DataSource ds;
    public  DbConn()
    {
        try{
        context=new InitialContext();
        ds=(DataSource) context.lookup("java:comp/env/jdbc/mysql");
        }
        catch(Exception e1)
        {
        }
    }
    public Connection get_connection()
    {
        try
        {
            /*Class.forName(driver1);
            Connection conn=DriverManager.getConnection(url1, user, password);
            return conn;*/
            
            //Context context=new InitialContext(); 
            //DataSource ds=(DataSource) context.lookup("java:comp/env/jdbc/mysql");
            Connection con;
            con = ds.getConnection();
            return con;
            
        }
        /*catch(ClassNotFoundException cnfe)
        {
            cnfe.printStackTrace();
        }*/
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        catch(Exception e1)
        {
            e1.printStackTrace();
        }
        return null;
    }
    public void close_connection(Connection conn)
    {
        try
        {
            if(conn!=null)
            {
                conn.close();
            }
        }
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        catch(Exception e1)
        {
            e1.printStackTrace();
        }
    }
}
