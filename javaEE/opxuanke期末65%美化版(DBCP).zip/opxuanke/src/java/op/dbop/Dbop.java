/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package op.dbop;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import op.dbconn.DbConn;

/**
 *
 * @author Administrator
 */
public class Dbop {
    public Dbop()
    {
        
    }
    public int dbop_update(String sql)
    { 
        try
        {
            DbConn db=new DbConn();
            Connection con=db.get_connection();
            Statement st=con.createStatement();
            int i= st.executeUpdate(sql);      
            //st.close();
            //con.close();
            return i;
        }
        catch(SQLException se)
        {
            return 0;
        }
    }
    public ResultSet dbop_query(String sql)
    { 
        try
        {
            DbConn db=new DbConn();
            Connection con=db.get_connection();
            Statement st=con.createStatement();
            ResultSet i=st.executeQuery(sql);
            return i;
        }
        catch(SQLException se)
        {
            return null;
        }
    }
    
}
