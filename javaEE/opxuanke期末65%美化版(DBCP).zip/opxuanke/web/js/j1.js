function st()
   {
		var to=new Date();
		var y=to.getFullYear();
		var m1=to.getMonth()+1;
        var d=to.getDate();
		var h=to.getHours();
		var m=to.getMinutes();
		var s=to.getSeconds();
		document.getElementById('b5').innerHTML
			=y+"年"+m1+"月"+d+"日"+
			h+":"+m+":"+s;
		t=setTimeout(st,500);
	}